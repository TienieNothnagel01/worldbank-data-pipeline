# World Bank Lakehouse Pipeline - Docker Edition

A containerized data lakehouse pipeline that extracts, transforms, and denormalizes World Bank development indicators into a medallion architecture (Bronze → Silver → Gold) using Apache Spark. The pipeline leverages modular notebooks in the `scripts/` directory for each layer, with an initial setup notebook for Silver DDL.

## 📑 Documentation

For in-depth information about the project:

* **[DESIGN_DECISIONS.md](DESIGN_DECISIONS.md)** - Details:
  * Schema design choices (star schema, medallion architecture)
  * Tool selection rationale (PySpark, Delta Lake, Docker, Databricks notebooks)
  * Notebook-driven workflow and separation of concerns
  * Data quality strategies
  * Known limitations and future improvements
  * Trade-offs and alternatives considered

* **[SUBMISSION.md](SUBMISSION.md)** - Step-by-step guide to:
  * Initialize Git repository
  * Create and push to GitHub
  * Verify submission checklist
  * Troubleshooting common issues

## 🏛 Architecture Overview


┌────────────────────────┐
│  World Bank API        │
│  (REST Endpoints)      │
└─────────┬──────────────┘
          │
          │ HTTP Requests
          │
          ↓
┌─────────┼───────────────────────────────┐
│  BRONZE LAYER (Raw Data)                │
│  • Extracts raw JSON from World Bank API│
│  • Saves as Parquet (append mode)       │
│  • Partitioned by extraction_date       │
│  • Includes audit columns & metadata    │
│  • Executed via notebook:               │
│    scripts/World Bank Bronze Extraction │
└─────────┬───────────────────────────────┘
          │
          │ PySpark
          │
          ↓
┌─────────┼───────────────────────────────┐
│  SILVER LAYER (Star Schema)             │
│  • dim_country, dim_indicator, dim_date │
│  • fact_indicator_values                │
│  • Data quality checks applied          │
│  • Surrogate keys generated             │
│  • Initial DDL setup via notebook:      │
│    scripts/World Bank Silver DDL - Initial Setup │
│  • Transformation via notebook:         │
│    scripts/World Bank Silver Transformation     │
└─────────┬───────────────────────────────┘
          │
          │ PySpark
          │
          ↓
┌─────────┼───────────────────────────────┐
│  GOLD LAYER (Reporting Ready)           │
│  • gold_country_indicators (Wide table) │
│  • gold_indicator_trends (Time series)  │
│  • gold_country_summary (Aggregations)  │
│  • Denormalized for BI tools            │
│  • Pre-calculated metrics               │
│  • Executed via notebook:               │
│    scripts/World Bank Gold Build        │
└──────────────────────────────────────────┘


## 📦 What's Inside

### Core Pipeline Notebooks & Scripts

* **scripts/World Bank Bronze Extraction** - Extracts data from World Bank API
  * Handles pagination, retries, and rate limiting
  * Supports multiple indicators and countries
  * Saves raw data as Parquet with audit metadata

* **scripts/World Bank Silver DDL - Initial Setup** - Creates Silver layer tables and objects

* **scripts/World Bank Silver Transformation** - Transforms Bronze to Silver star schema
  * Creates dimension tables (country, indicator, date)
  * Builds fact table with surrogate keys
  * Applies data quality validation

* **scripts/World Bank Gold Build** - Denormalizes Silver to Gold reporting layer
  * Wide table with all indicators by country/year
  * Time-series trends with YoY calculations
  * Country summary statistics

* **run_pipeline.py** - Orchestrates full pipeline execution (calls notebooks/scripts)
  * Sequential execution: Bronze → Silver → Gold
  * Error handling and logging
  * Pipeline summary reporting

### Configuration Files

* **Dockerfile.py** - Multi-stage Docker image with Python 3.10 + Spark
* **docker-compose.yml** - Container orchestration with volumes and networking
* **requirements.txt** - Python dependencies (PySpark, pandas, requests, etc.)
* **entrypoint.sh** - Container entry point with mode selection
* **.env.example** - Environment variable template
* **.dockerignore** - Files excluded from Docker build

## 🚀 Quick Start

### Prerequisites

* Docker 20.10+
* Docker Compose 2.0+
* 4GB RAM minimum (8GB recommended)
* Internet connection (for World Bank API)

### 1. Clone and Setup

bash
cd worldbank-docker
cp .env.example .env
vim .env


### 2. Configure Environment (Optional)

Edit `.env` to customize:

bash
WB_INDICATORS=NY.GDP.MKTP.CD,SP.POP.TOTL,EN.ATM.CO2E.PC
WB_COUNTRIES=USA,CHN,IND,BRA,DEU,GBR,FRA,JPN
WB_START_YEAR=2010
WB_END_YEAR=2023


### 3. Build and Run

bash
docker-compose build
docker-compose up
docker-compose up -d
docker-compose logs -f


### 4. Access Data

Data is stored in local directories mounted as volumes:

bash
./data/bronze/world_bank_indicators/
./data/silver/dim_country/
./data/silver/dim_indicator/
./data/silver/dim_date/
./data/silver/fact_indicator_values/
./data/gold/gold_country_indicators/
./data/gold/gold_indicator_trends/
./data/gold/gold_country_summary/
./logs/


## ⚙️ Pipeline Modes

The pipeline supports partial execution:

bash
docker-compose run worldbank-pipeline bronze
docker-compose run worldbank-pipeline silver
docker-compose run worldbank-pipeline gold
docker-compose run worldbank-pipeline bronze-silver
docker-compose run worldbank-pipeline silver-gold
docker-compose run worldbank-pipeline full


Or set in `.env`:

bash
PIPELINE_MODE=bronze-silver
docker-compose up


## 📋 Environment Variables Reference

| Variable           | Description                                      | Example Value                                 |
|--------------------|--------------------------------------------------|-----------------------------------------------|
| WB_INDICATORS      | Comma-separated list of indicator codes           | NY.GDP.MKTP.CD,SP.POP.TOTL                    |
| WB_COUNTRIES       | Comma-separated list of country codes             | USA,CHN,IND                                   |
| WB_START_YEAR      | Start year for extraction                         | 2010                                          |
| WB_END_YEAR        | End year for extraction                           | 2023                                          |
| PIPELINE_MODE      | Pipeline execution mode                           | bronze, silver, gold, bronze-silver, full     |
| DATA_DIR           | Data storage directory                            | ./data                                        |
| LOG_DIR            | Log storage directory                             | ./logs                                        |

## 📊 Common World Bank Indicators

| Indicator Code     | Description                                      |
|--------------------|--------------------------------------------------|
| NY.GDP.MKTP.CD     | GDP (current US$)                                |
| SP.POP.TOTL        | Total Population                                 |
| EN.ATM.CO2E.PC     | CO2 emissions (metric tons per capita)           |
| SE.XPD.TOTL.GD.ZS  | Education expenditure (% of GDP)                 |
| SH.DYN.MORT        | Mortality rate, infant (per 1,000 live births)   |
| IT.NET.USER.ZS     | Internet users (% of population)                 |

## 👀 Monitoring

### Spark UI

http://localhost:4040

### Container Logs

bash
docker-compose logs -f
docker-compose logs --since 10m
docker logs worldbank-lakehouse


### Pipeline Logs

bash
ls -lt ./logs/bronze_extraction_*.log | head -1 | xargs cat
ls -lt ./logs/silver_transformation_*.log | head -1 | xargs cat
ls -lt ./logs/gold_build_*.log | head -1 | xargs cat


## 🧪 Running Tests

Comprehensive test suite covering all pipeline layers. Notebooks are tested via script wrappers and unit tests.

### Prerequisites

bash
pip install -r tests/requirements-test.txt


### Run All Tests

bash
pytest tests/test_pipeline.py -v
pytest tests/test_pipeline.py --cov=scripts --cov-report=html
pytest tests/test_pipeline.py::TestBronzeLayer -v
pytest tests/test_pipeline.py::TestBronzeLayer::test_api_response_parsing -v


### Test Coverage

Test coverage reports are generated in `htmlcov/` after running with `--cov`. Review the HTML report for detailed coverage metrics.

### Test Without Spark

All tests use mocks and do NOT require:
* Live World Bank API access
* Running Spark cluster
* Docker containers

## 🔍 Data Exploration

### Using PySpark Shell

bash
docker exec -it worldbank-lakehouse bash
pyspark


python
df = spark.read.parquet("/app/data/gold/gold_country_indicators")
df.printSchema()
df.show(10, truncate=False)
df.filter(df.country_code == "USA").orderBy("year").select("year", "country_name", "NY.GDP.MKTP.CD").show()


### Using Python

bash
docker exec -it worldbank-lakehouse python3


python
import pandas as pd
df = pd.read_parquet("/app/data/gold/gold_country_summary")
print(df.head())
print(df.describe())


## 🛠️ Troubleshooting

* Check container logs for errors: `docker-compose logs -f`
* Verify `.env` configuration for correct indicator and country codes
* Ensure Docker volumes are mounted and accessible
* Review pipeline logs in `./logs/` for extraction and transformation issues
* For Spark errors, access Spark UI at `http://localhost:4040`
* If tests fail, review `tests/requirements-test.txt` and ensure dependencies are installed

## 📚 Data Schema Reference

### Bronze Layer

* Raw JSON from World Bank API
* Partitioned by extraction_date
* Includes audit columns: extraction_date, source_url, record_id

### Silver Layer

* `dim_country`: country_code, country_name, region, income_group
* `dim_indicator`: indicator_code, indicator_name, category
* `dim_date`: year, month, quarter
* `fact_indicator_values`: country_key, indicator_key, date_key, value, quality_flag

### Gold Layer

* `gold_country_indicators`: country_code, year, [indicator columns...]
* `gold_indicator_trends`: indicator_code, year, trend_value, YoY_change
* `gold_country_summary`: country_code, summary_stats (mean, median, min, max)

## 🔄 Updating and Refreshing Data

* To refresh data, update `WB_START_YEAR` and `WB_END_YEAR` in `.env`
* Re-run pipeline with `docker-compose up`
* For incremental updates, set `PIPELINE_MODE=bronze-silver` or `silver-gold`
* Data is appended to existing Parquet files; ensure partitioning by extraction_date

## 📦 Production Deployment

* Build Docker image: `docker-compose build`
* Push image to registry if needed
* Configure environment variables for production
* Use orchestration tools (Kubernetes, ECS) for scaling
* Set up monitoring and alerting for pipeline failures

## 📝 License

This project is provided as-is for educational and analytical purposes. World Bank data is subject to the [World Bank Terms of Use](https://www.worldbank.org/en/about/legal/terms-of-use-for-datasets).

## 🔗 Useful Links

* [World Bank API Documentation](https://datahelpdesk.worldbank.org/knowledgebase/topics/125589)
* [World Bank Data Catalog](https://datacatalog.worldbank.org/)
* [PySpark Documentation](https://spark.apache.org/docs/latest/api/python/)
* [Docker Documentation](https://docs.docker.com/)
* [Medallion Architecture](https://www.databricks.com/glossary/medallion-architecture)

## 👥 Contributing

Contributions welcome! Areas for improvement:
* Additional data quality checks
* More Gold layer aggregations
* Integration with BI tools (Tableau, Power BI)
* Support for incremental updates
* Unit tests and CI/CD
* Performance optimizations

---

**Built with ❤️ using Apache Spark, Docker, Databricks notebooks, and the World Bank API**