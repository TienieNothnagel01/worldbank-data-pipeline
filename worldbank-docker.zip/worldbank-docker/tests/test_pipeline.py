#!/usr/bin/env python3
"""
World Bank Data Pipeline - Unit Tests

Comprehensive test suite for the World Bank data pipeline covering:
- Bronze layer: API extraction and data parsing
- Silver layer: Star schema transformation and data quality
- Gold layer: Denormalization and aggregation logic

Run with: pytest tests/test_pipeline.py -v

Note: Tests use mocks and do NOT require live API access or Spark cluster.
"""

import pytest
import json
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
import sys
import os

# Add scripts directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def mock_api_response():
    """Mock World Bank API response with pagination metadata."""
    return [
        {
            "page": 1,
            "pages": 2,
            "per_page": 2,
            "total": 4
        },
        [
            {
                "indicator": {"id": "NY.GDP.MKTP.CD", "value": "GDP (current US$)"},
                "country": {"id": "US", "value": "United States"},
                "countryiso3code": "USA",
                "date": "2023",
                "value": 27360935000000,
                "unit": "",
                "obs_status": "",
                "decimal": 0
            },
            {
                "indicator": {"id": "NY.GDP.MKTP.CD", "value": "GDP (current US$)"},
                "country": {"id": "US", "value": "United States"},
                "countryiso3code": "USA",
                "date": "2022",
                "value": 25744098000000,
                "unit": "",
                "obs_status": "",
                "decimal": 0
            }
        ]
    ]


@pytest.fixture
def mock_country_data():
    """Mock country dimension data."""
    return [
        {
            "id": "ABW",
            "iso2Code": "AW",
            "name": "Aruba",
            "region": {
                "id": "LCN",
                "iso2code": "ZJ",
                "value": "Latin America & Caribbean "
            },
            "adminregion": {"id": "", "iso2code": "", "value": ""},
            "incomeLevel": {
                "id": "HIC",
                "iso2code": "XD",
                "value": "High income"
            },
            "lendingType": {
                "id": "LNX",
                "iso2code": "XX",
                "value": "Not classified"
            },
            "capitalCity": "Oranjestad",
            "longitude": "-70.0167",
            "latitude": "12.5167"
        }
    ]


@pytest.fixture
def mock_indicator_records():
    """Mock parsed indicator records."""
    return [
        {
            "indicator_id": "NY.GDP.MKTP.CD",
            "indicator_name": "GDP (current US$)",
            "country_id": "USA",
            "country_name": "United States",
            "country_code": "USA",
            "year": "2023",
            "value": 27360935000000.0,
            "unit": "",
            "obs_status": "",
            "decimal": 0
        },
        {
            "indicator_id": "NY.GDP.MKTP.CD",
            "indicator_name": "GDP (current US$)",
            "country_id": "USA",
            "country_name": "United States",
            "country_code": "USA",
            "year": "2022",
            "value": 25744098000000.0,
            "unit": "",
            "obs_status": "",
            "decimal": 0
        }
    ]


# ============================================================================
# BRONZE LAYER TESTS - API Extraction
# ============================================================================

class TestBronzeLayer:
    """Tests for Bronze layer data extraction."""
    
    def test_api_response_parsing(self, mock_api_response):
        """Test that API responses are correctly parsed."""
        metadata, records = mock_api_response
        
        # Verify metadata structure
        assert "page" in metadata
        assert "pages" in metadata
        assert "total" in metadata
        
        # Verify pagination info
        assert metadata["page"] == 1
        assert metadata["pages"] == 2
        assert metadata["total"] == 4
        
        # Verify records structure
        assert len(records) == 2
        assert all("indicator" in r for r in records)
        assert all("country" in r for r in records)
        assert all("value" in r for r in records)
    
    def test_indicator_record_transformation(self, mock_api_response):
        """Test transformation of raw API records."""
        _, records = mock_api_response
        record = records[0]
        
        # Transform record (simulating extract_bronze.py logic)
        transformed = {
            "indicator_id": record["indicator"]["id"],
            "indicator_name": record["indicator"]["value"],
            "country_id": record["country"]["id"],
            "country_name": record["country"]["value"],
            "country_code": record["countryiso3code"],
            "year": record["date"],
            "value": record["value"],
            "extraction_timestamp": datetime.now().isoformat()
        }
        
        # Verify transformation
        assert transformed["indicator_id"] == "NY.GDP.MKTP.CD"
        assert transformed["country_code"] == "USA"
        assert transformed["year"] == "2023"
        assert transformed["value"] == 27360935000000
        assert "extraction_timestamp" in transformed
    
    def test_handles_null_values(self):
        """Test handling of null/missing values in API response."""
        record_with_null = {
            "indicator": {"id": "SP.POP.TOTL", "value": "Population, total"},
            "country": {"id": "US", "value": "United States"},
            "countryiso3code": "USA",
            "date": "2023",
            "value": None,  # Null value
            "unit": "",
            "obs_status": "",
            "decimal": 0
        }
        
        # Should handle null gracefully
        transformed = {
            "indicator_id": record_with_null["indicator"]["id"],
            "country_code": record_with_null["countryiso3code"],
            "year": record_with_null["date"],
            "value": record_with_null["value"],
        }
        
        assert transformed["value"] is None
        assert transformed["year"] == "2023"
    
    def test_country_parsing(self, mock_country_data):
        """Test parsing of country dimension data."""
        country = mock_country_data[0]
        
        # Parse country record
        parsed = {
            "country_id": country["id"],
            "country_code": country["iso2Code"],
            "country_code_iso3": country["id"],
            "country_name": country["name"],
            "region_id": country["region"]["id"],
            "region_name": country["region"]["value"].strip(),
            "income_level_id": country["incomeLevel"]["id"],
            "income_level_name": country["incomeLevel"]["value"],
            "capital_city": country["capitalCity"],
        }
        
        assert parsed["country_id"] == "ABW"
        assert parsed["country_code"] == "AW"
        assert parsed["country_name"] == "Aruba"
        assert parsed["region_name"] == "Latin America & Caribbean"
        assert parsed["income_level_name"] == "High income"
    
    def test_filters_aggregates(self, mock_country_data):
        """Test that regional aggregates are filtered out."""
        # Add an aggregate to the data
        aggregate = {
            "id": "AFE",
            "name": "Africa Eastern and Southern",
            "region": {"id": "NA", "value": "Aggregates"},
            "incomeLevel": {"id": "NA", "value": "Aggregates"},
        }
        
        # Should be filtered based on region == "Aggregates"
        is_aggregate = aggregate["region"]["value"] == "Aggregates"
        assert is_aggregate is True
        
        # Real country should not be filtered
        real_country = mock_country_data[0]
        is_real = real_country["region"]["value"] != "Aggregates"
        assert is_real is True


# ============================================================================
# SILVER LAYER TESTS - Star Schema Transformation
# ============================================================================

class TestSilverLayer:
    """Tests for Silver layer star schema transformation."""
    
    def test_dimension_deduplication(self):
        """Test that dimension tables handle duplicates correctly."""
        countries = [
            {"country_code": "USA", "country_name": "United States"},
            {"country_code": "USA", "country_name": "United States"},  # Duplicate
            {"country_code": "CHN", "country_name": "China"},
        ]
        
        # Deduplicate (simulating MERGE behavior)
        unique_countries = {c["country_code"]: c for c in countries}
        
        assert len(unique_countries) == 2
        assert "USA" in unique_countries
        assert "CHN" in unique_countries
    
    def test_fact_table_grain(self, mock_indicator_records):
        """Test that fact table maintains correct grain (country + indicator + year)."""
        # Grain should be: country_code + indicator_id + year
        grains = set()
        for record in mock_indicator_records:
            grain = (record["country_code"], record["indicator_id"], record["year"])
            grains.add(grain)
        
        # Should have 2 unique grains (USA GDP for 2023 and 2022)
        assert len(grains) == 2
        assert ("USA", "NY.GDP.MKTP.CD", "2023") in grains
        assert ("USA", "NY.GDP.MKTP.CD", "2022") in grains
    
    def test_null_value_handling(self):
        """Test handling of null values in fact table."""
        records = [
            {"country_code": "USA", "indicator_id": "NY.GDP.MKTP.CD", "year": "2023", "value": 27360935000000.0},
            {"country_code": "USA", "indicator_id": "NY.GDP.MKTP.CD", "year": "2022", "value": None},  # Null
        ]
        
        # Null values should be preserved (not filtered)
        non_null_count = sum(1 for r in records if r["value"] is not None)
        null_count = sum(1 for r in records if r["value"] is None)
        
        assert non_null_count == 1
        assert null_count == 1
        assert len(records) == 2  # Both records preserved
    
    def test_surrogate_key_generation(self):
        """Test generation of surrogate keys for dimensions."""
        countries = [
            {"country_code": "USA", "country_name": "United States"},
            {"country_code": "CHN", "country_name": "China"},
        ]
        
        # Simulate surrogate key assignment
        for i, country in enumerate(countries, start=1):
            country["country_key"] = i
        
        assert countries[0]["country_key"] == 1
        assert countries[1]["country_key"] == 2
        assert all("country_key" in c for c in countries)
    
    def test_referential_integrity(self):
        """Test that fact records reference valid dimension keys."""
        # Dimension tables
        dim_country = {"USA": 1, "CHN": 2}  # country_code -> country_key
        dim_indicator = {"NY.GDP.MKTP.CD": 1}  # indicator_id -> indicator_key
        
        # Fact record
        fact = {
            "country_code": "USA",
            "indicator_id": "NY.GDP.MKTP.CD",
            "year": "2023",
            "value": 27360935000000.0
        }
        
        # Check referential integrity
        has_valid_country = fact["country_code"] in dim_country
        has_valid_indicator = fact["indicator_id"] in dim_indicator
        
        assert has_valid_country is True
        assert has_valid_indicator is True


# ============================================================================
# GOLD LAYER TESTS - Denormalization & Aggregation
# ============================================================================

class TestGoldLayer:
    """Tests for Gold layer denormalization and reporting."""
    
    def test_wide_table_pivot(self):
        """Test pivot logic for wide-format indicator table."""
        # Input: Long format
        long_data = [
            {"country_code": "USA", "year": 2023, "indicator_id": "NY.GDP.MKTP.CD", "value": 27360935000000.0},
            {"country_code": "USA", "year": 2023, "indicator_id": "SP.POP.TOTL", "value": 339996564.0},
        ]
        
        # Output: Wide format (simulated pivot)
        wide_data = {
            "country_code": "USA",
            "year": 2023,
            "NY.GDP.MKTP.CD": 27360935000000.0,
            "SP.POP.TOTL": 339996564.0
        }
        
        # Verify pivot structure
        assert wide_data["country_code"] == "USA"
        assert wide_data["year"] == 2023
        assert "NY.GDP.MKTP.CD" in wide_data
        assert "SP.POP.TOTL" in wide_data
    
    def test_yoy_calculation(self):
        """Test year-over-year change calculation."""
        data = [
            {"year": 2022, "value": 25744098000000.0},
            {"year": 2023, "value": 27360935000000.0},
        ]
        
        # Calculate YoY change
        yoy_change = data[1]["value"] - data[0]["value"]
        yoy_change_pct = ((data[1]["value"] - data[0]["value"]) / data[0]["value"]) * 100
        
        assert yoy_change > 0  # GDP increased
        assert yoy_change == 1616837000000.0
        assert round(yoy_change_pct, 2) == 6.28  # ~6.28% increase
    
    def test_aggregation_statistics(self):
        """Test calculation of global statistics."""
        values = [100.0, 200.0, 300.0, 400.0, 500.0]
        
        # Calculate statistics
        count = len(values)
        mean = sum(values) / count
        min_val = min(values)
        max_val = max(values)
        
        assert count == 5
        assert mean == 300.0
        assert min_val == 100.0
        assert max_val == 500.0
    
    def test_completeness_score(self):
        """Test data completeness calculation."""
        # Country has data for 10 out of 14 years for 3 indicators
        actual_points = 30
        max_possible_points = 14 * 3  # 14 years * 3 indicators = 42
        
        completeness_score = (actual_points / max_possible_points) * 100
        
        assert completeness_score == pytest.approx(71.43, rel=0.01)
    
    def test_country_summary_aggregation(self):
        """Test country summary statistics."""
        records = [
            {"country_code": "USA", "year": 2020, "indicator_id": "NY.GDP.MKTP.CD", "value": 20.9},
            {"country_code": "USA", "year": 2021, "indicator_id": "NY.GDP.MKTP.CD", "value": 23.3},
            {"country_code": "USA", "year": 2020, "indicator_id": "SP.POP.TOTL", "value": 331.9},
        ]
        
        # Aggregate
        country_summary = {
            "country_code": "USA",
            "first_year": min(r["year"] for r in records),
            "last_year": max(r["year"] for r in records),
            "year_count": len(set(r["year"] for r in records)),
            "indicator_count": len(set(r["indicator_id"] for r in records)),
            "total_data_points": len(records)
        }
        
        assert country_summary["first_year"] == 2020
        assert country_summary["last_year"] == 2021
        assert country_summary["year_count"] == 2
        assert country_summary["indicator_count"] == 2
        assert country_summary["total_data_points"] == 3


# ============================================================================
# DATA QUALITY TESTS
# ============================================================================

class TestDataQuality:
    """Tests for data quality validation."""
    
    def test_no_duplicate_facts(self, mock_indicator_records):
        """Test that fact table has no duplicates at the grain level."""
        # Create composite keys
        keys = set()
        for record in mock_indicator_records:
            key = (record["country_code"], record["indicator_id"], record["year"])
            keys.add(key)
        
        # Number of unique keys should equal number of records
        assert len(keys) == len(mock_indicator_records)
    
    def test_required_fields_present(self, mock_indicator_records):
        """Test that all required fields are present."""
        required_fields = ["indicator_id", "country_code", "year", "value"]
        
        for record in mock_indicator_records:
            for field in required_fields:
                assert field in record
    
    def test_year_format_validation(self, mock_indicator_records):
        """Test that year values are in correct format."""
        for record in mock_indicator_records:
            year = record["year"]
            # Should be numeric string
            assert year.isdigit()
            # Should be 4 characters
            assert len(year) == 4
            # Should be reasonable year
            assert 2000 <= int(year) <= 2030
    
    def test_country_code_format(self, mock_indicator_records):
        """Test that country codes are ISO3 format."""
        for record in mock_indicator_records:
            country_code = record["country_code"]
            # Should be 3 characters
            assert len(country_code) == 3
            # Should be uppercase
            assert country_code.isupper()
    
    def test_numeric_values_type(self, mock_indicator_records):
        """Test that numeric values are properly typed."""
        for record in mock_indicator_records:
            value = record["value"]
            # Should be float or None
            assert isinstance(value, (float, int, type(None)))


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """End-to-end integration tests."""
    
    @patch('requests.get')
    def test_end_to_end_extraction(self, mock_get, mock_api_response):
        """Test complete extraction workflow with mocked API."""
        # Mock API response
        mock_response = Mock()
        mock_response.json.return_value = mock_api_response
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        # Simulate extraction
        import requests
        response = requests.get("https://api.worldbank.org/v2/country/USA/indicator/NY.GDP.MKTP.CD")
        data = response.json()
        
        # Verify
        assert data is not None
        assert len(data) == 2
        metadata, records = data
        assert "page" in metadata
        assert len(records) > 0
    
    def test_bronze_to_silver_transformation(self, mock_indicator_records):
        """Test transformation from Bronze to Silver."""
        # Bronze records
        bronze_records = mock_indicator_records
        
        # Create dimensions from bronze
        dim_country = {r["country_code"]: r["country_name"] for r in bronze_records}
        dim_indicator = {r["indicator_id"]: r["indicator_name"] for r in bronze_records}
        
        # Create fact records
        fact_records = [
            {
                "country_code": r["country_code"],
                "indicator_id": r["indicator_id"],
                "year": r["year"],
                "value": r["value"]
            }
            for r in bronze_records
        ]
        
        # Verify transformation
        assert len(dim_country) == 1  # 1 unique country
        assert len(dim_indicator) == 1  # 1 unique indicator
        assert len(fact_records) == 2  # 2 fact records
    
    def test_silver_to_gold_denormalization(self):
        """Test denormalization from Silver to Gold."""
        # Silver fact table (normalized)
        silver_facts = [
            {"country_code": "USA", "indicator_id": "NY.GDP.MKTP.CD", "year": 2023, "value": 27.36},
            {"country_code": "USA", "indicator_id": "SP.POP.TOTL", "year": 2023, "value": 339.99},
        ]
        
        # Gold wide table (denormalized)
        gold_wide = {}
        for fact in silver_facts:
            key = (fact["country_code"], fact["year"])
            if key not in gold_wide:
                gold_wide[key] = {
                    "country_code": fact["country_code"],
                    "year": fact["year"]
                }
            gold_wide[key][fact["indicator_id"]] = fact["value"]
        
        # Verify denormalization
        assert len(gold_wide) == 1  # 1 country-year combination
        record = gold_wide[("USA", 2023)]
        assert "NY.GDP.MKTP.CD" in record
        assert "SP.POP.TOTL" in record
        assert record["NY.GDP.MKTP.CD"] == 27.36


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
