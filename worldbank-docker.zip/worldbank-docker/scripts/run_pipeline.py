#!/usr/bin/env python3
"""
World Bank Lakehouse Pipeline Orchestrator

Orchestrates the full pipeline execution:
1. Bronze: Extract data from World Bank API
2. Silver: Transform into star schema
3. Gold: Create denormalized reporting tables
"""

import os
import sys
import time
import logging
from datetime import datetime
from pathlib import Path
from databricks.sdk.runtime import dbutils


class PipelineOrchestrator:
    """Orchestrates the World Bank lakehouse pipeline."""
    
    def __init__(self):
        """Initialize orchestrator with configuration."""
        self.scripts_dir = Path(__file__).parent
        
        # Setup logging
        log_level = os.getenv('LOG_LEVEL', 'INFO')
        self.logger = logging.getLogger('WorldBankPipeline')
        self.logger.setLevel(getattr(logging, log_level))
        
        # Clear any existing handlers
        self.logger.handlers.clear()
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(getattr(logging, log_level))
        formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)
        
        # File handler
        log_dir = os.getenv('LOGS_PATH', '/app/logs')
        os.makedirs(log_dir, exist_ok=True)
        log_file = f"{log_dir}/pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, log_level))
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
        
        self.logger.info("Initialized PipelineOrchestrator")
        self.logger.info(f"Scripts directory: {self.scripts_dir}")
    
    def run_stage(self, stage_name: str, notebook_path: str) -> bool:
        """Run a single pipeline stage by calling a Databricks notebook."""
        self.logger.info("="*60)
        self.logger.info(f"Starting {stage_name} stage")
        self.logger.info("="*60)
        
        start_time = time.time()
        
        try:
            result = dbutils.notebook.run(notebook_path, 0)
            self.logger.info(f"{stage_name} notebook output:\n{result}")
            
            elapsed_time = time.time() - start_time
            self.logger.info("="*60)
            self.logger.info(f"{stage_name} completed successfully in {elapsed_time:.2f} seconds")
            self.logger.info("="*60)
            
            return True
            
        except Exception as e:
            elapsed_time = time.time() - start_time
            self.logger.error("="*60)
            self.logger.error(f"{stage_name} failed after {elapsed_time:.2f} seconds")
            self.logger.error(f"Exception: {e}", exc_info=True)
            self.logger.error("="*60)
            return False
    
    def validate_environment(self):
        """Validate that required environment variables are set."""
        self.logger.info("Validating environment configuration...")
        
        # Set defaults for Databricks environment if not running in Docker
        if not os.getenv('BRONZE_PATH'):
            os.environ['BRONZE_PATH'] = '/tmp/bronze'
            self.logger.info("Using default BRONZE_PATH: /tmp/bronze")
        
        if not os.getenv('SILVER_PATH'):
            os.environ['SILVER_PATH'] = '/tmp/silver'
            self.logger.info("Using default SILVER_PATH: /tmp/silver")
        
        if not os.getenv('GOLD_PATH'):
            os.environ['GOLD_PATH'] = '/tmp/gold'
            self.logger.info("Using default GOLD_PATH: /tmp/gold")
        
        if not os.getenv('WB_API_BASE_URL'):
            os.environ['WB_API_BASE_URL'] = 'https://api.worldbank.org/v2'
            self.logger.info("Using default WB_API_BASE_URL: https://api.worldbank.org/v2")
        
        self.logger.info("Environment validation passed")
        return True
    
    def check_data_paths(self):
        """Ensure data directories exist."""
        self.logger.info("Checking data paths...")
        
        paths = [
            os.getenv('BRONZE_PATH'),
            os.getenv('SILVER_PATH'),
            os.getenv('GOLD_PATH'),
            os.getenv('LOGS_PATH')
        ]
        
        for path in paths:
            if path:
                os.makedirs(path, exist_ok=True)
                self.logger.info(f"Path ready: {path}")
        
        self.logger.info("All data paths ready")
    
    def log_pipeline_config(self):
        """Log pipeline configuration for tracking."""
        self.logger.info("Pipeline Configuration:")
        self.logger.info(f"  World Bank API: {os.getenv('WB_API_BASE_URL')}")
        self.logger.info(f"  Indicators: {os.getenv('WB_INDICATORS')}")
        self.logger.info(f"  Countries: {os.getenv('WB_COUNTRIES')}")
        self.logger.info(f"  Year range: {os.getenv('WB_START_YEAR')} - {os.getenv('WB_END_YEAR')}")
        self.logger.info(f"  Bronze path: {os.getenv('BRONZE_PATH')}")
        self.logger.info(f"  Silver path: {os.getenv('SILVER_PATH')}")
        self.logger.info(f"  Gold path: {os.getenv('GOLD_PATH')}")
        self.logger.info(f"  Log level: {os.getenv('LOG_LEVEL')}")
    
    def run_full_pipeline(self) -> bool:
        """Run the complete pipeline: Bronze → Silver → Gold."""
        self.logger.info("#" * 70)
        self.logger.info("#" + " " * 68 + "#")
        self.logger.info("#" + "  World Bank Lakehouse Pipeline - Full Execution".center(68) + "#")
        self.logger.info("#" + " " * 68 + "#")
        self.logger.info("#" * 70)
        self.logger.info(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("#" * 70)
        
        # Validate environment
        if not self.validate_environment():
            self.logger.error("Environment validation failed. Aborting pipeline.")
            return False
        
        # Check data paths
        self.check_data_paths()
        
        # Log configuration
        self.log_pipeline_config()
        
        pipeline_start = time.time()
        
        # Stage 1: Bronze (Extract)
        if not self.run_stage("Bronze", "/World Bank Bronze Extraction"):
            self.logger.error("Bronze stage failed. Aborting pipeline.")
            return False
        
        # Stage 2: Silver (Transform)
        if not self.run_stage("Silver", "/World Bank Silver Transformation"):
            self.logger.error("Silver stage failed. Aborting pipeline.")
            return False
        
        # Stage 3: Gold (Denormalize)
        if not self.run_stage("Gold", "/World Bank Gold Layer Build"):
            self.logger.error("Gold stage failed. Aborting pipeline.")
            return False
        
        # Success!
        total_elapsed = time.time() - pipeline_start
        
        self.logger.info("#" * 70)
        self.logger.info("#" + " " * 68 + "#")
        self.logger.info("#" + "  PIPELINE COMPLETED SUCCESSFULLY!".center(68) + "#")
        self.logger.info("#" + " " * 68 + "#")
        self.logger.info("#" * 70)
        self.logger.info(f"Total execution time: {total_elapsed:.2f} seconds ({total_elapsed/60:.2f} minutes)")
        self.logger.info(f"Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("#" * 70)
        
        return True
    
    def generate_pipeline_summary(self):
        """Generate a summary of pipeline execution."""
        self.logger.info("Generating pipeline summary...")
        
        bronze_path = os.getenv('BRONZE_PATH')
        silver_path = os.getenv('SILVER_PATH')
        gold_path = os.getenv('GOLD_PATH')
        
        self.logger.info("\nPipeline Summary:")
        self.logger.info("=" * 60)
        
        # Check Bronze layer
        bronze_dir = Path(bronze_path) / "world_bank_indicators"
        if bronze_dir.exists():
            self.logger.info(f"Bronze layer: {bronze_dir}")
        
        # Check Silver layer
        silver_tables = ['dim_country', 'dim_indicator', 'dim_date', 'fact_indicator_values']
        self.logger.info("\nSilver layer tables:")
        for table in silver_tables:
            table_path = Path(silver_path) / table
            if table_path.exists():
                self.logger.info(f"  ✓ {table}")
            else:
                self.logger.info(f"  ✗ {table} (missing)")
        
        # Check Gold layer
        gold_tables = ['gold_country_indicators', 'gold_indicator_trends', 'gold_country_summary']
        self.logger.info("\nGold layer tables:")
        for table in gold_tables:
            table_path = Path(gold_path) / table
            if table_path.exists():
                self.logger.info(f"  ✓ {table}")
            else:
                self.logger.info(f"  ✗ {table} (missing)")
        
        self.logger.info("=" * 60)


def main():
    """Main execution function."""
    try:
        orchestrator = PipelineOrchestrator()
        
        # Run the full pipeline
        success = orchestrator.run_full_pipeline()
        
        # Generate summary
        orchestrator.generate_pipeline_summary()
        
        return 0 if success else 1
        
    except KeyboardInterrupt:
        logging.warning("Pipeline interrupted by user")
        return 130
    
    except Exception as e:
        logging.error(f"Pipeline orchestration failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
