# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Title and Description
# MAGIC %md
# MAGIC # World Bank Data Transformation - Silver Layer (Incremental)
# MAGIC
# MAGIC **Purpose**: Incrementally transforms Bronze layer data into a star schema using **MERGE** logic with stable surrogate keys.
# MAGIC
# MAGIC **Star Schema Design**:
# MAGIC * **Dimensions**: Country, Indicator, Date (slowly changing dimensions)
# MAGIC * **Fact Table**: Indicator values with foreign keys to all dimensions
# MAGIC
# MAGIC **Load Strategy**: **Incremental MERGE with Stable Surrogate Keys**
# MAGIC * Uses `MERGE INTO` to preserve existing surrogate keys
# MAGIC * **MATCHED records**: Updates with new values and timestamps
# MAGIC * **NOT MATCHED records**: Inserts with auto-incremented surrogate keys
# MAGIC * Surrogate keys remain stable across runs - no regeneration
# MAGIC * Efficient - only processes new/changed data
# MAGIC
# MAGIC **Prerequisites**:
# MAGIC ⚠️ Run "World Bank Silver DDL - Initial Setup" notebook ONCE before using this for the first time.
# MAGIC
# MAGIC **Benefits**:
# MAGIC * Optimized for analytical queries and aggregations
# MAGIC * Maintains referential integrity with stable keys
# MAGIC * Supports time-series analysis and trend identification
# MAGIC * Partitioned by date for query performance
# MAGIC
# MAGIC **Architecture**: Bronze → Silver (star schema) → Gold (aggregated/business metrics)

# COMMAND ----------

# DBTITLE 1,Two-Notebook Approach
# MAGIC %md
# MAGIC ## Two-Notebook Approach
# MAGIC
# MAGIC ### 1️⃣ Initial Setup: "World Bank Silver DDL - Initial Setup"
# MAGIC **Run ONCE** when setting up the Silver layer for the first time.
# MAGIC * Uses `CREATE OR REPLACE TABLE` to build all dimension and fact tables from scratch
# MAGIC * Generates initial surrogate keys using `ROW_NUMBER()`
# MAGIC * ⚠️ Destructive - drops existing data
# MAGIC
# MAGIC ### 2️⃣ Incremental Updates: This Notebook
# MAGIC **Run REPEATEDLY** for daily/regular data refreshes.
# MAGIC * Uses `MERGE INTO` to update existing records and insert new ones
# MAGIC * Preserves surrogate keys - existing keys never change
# MAGIC * New records get auto-incremented keys starting from MAX(key) + 1
# MAGIC * Non-destructive - maintains history and referential integrity
# MAGIC
# MAGIC **Key Differences**:
# MAGIC | Aspect | Initial DDL | Incremental (This) |
# MAGIC |--------|-------------|--------------------|
# MAGIC | Frequency | Once | Repeatedly |
# MAGIC | Strategy | CREATE OR REPLACE | MERGE INTO |
# MAGIC | Surrogate Keys | Regenerated | Stable/Preserved |
# MAGIC | Data Loss | Yes | No |
# MAGIC | Use Case | First-time setup | Daily/regular updates |

# COMMAND ----------

# DBTITLE 1,Configuration
# Source configuration
SOURCE_CATALOG = 'world_bank'
SOURCE_SCHEMA = 'bronze'
SOURCE_TABLE = 'indicators'

# Target configuration
TARGET_CATALOG = 'world_bank'
TARGET_SCHEMA = 'silver'

# Dimension tables
DIM_COUNTRY = 'dim_country'
DIM_INDICATOR = 'dim_indicator'
DIM_DATE = 'dim_date'

# Fact table
FACT_INDICATOR_VALUES = 'fact_indicator_values'

# Full paths
source_table = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{SOURCE_TABLE}"
target_schema = f"{TARGET_CATALOG}.{TARGET_SCHEMA}"

print(f"Configuration loaded:")
print(f"  Source: {source_table}")
print(f"  Target schema: {target_schema}")
print(f"  Dimensions: {DIM_COUNTRY}, {DIM_INDICATOR}, {DIM_DATE}")
print(f"  Fact table: {FACT_INDICATOR_VALUES}")

# COMMAND ----------

# DBTITLE 1,Create Silver Schema
# MAGIC %sql
# MAGIC -- Create Silver schema for star schema tables
# MAGIC CREATE SCHEMA IF NOT EXISTS world_bank.silver
# MAGIC COMMENT 'Silver layer: Star schema for World Bank data with dimensions and fact tables';

# COMMAND ----------

# DBTITLE 1,Read and Clean Bronze Data
# MAGIC %sql
# MAGIC -- Create temp view of clean bronze data
# MAGIC CREATE OR REPLACE TEMP VIEW bronze_clean AS
# MAGIC SELECT *
# MAGIC FROM  world_bank.bronze.indicators
# MAGIC WHERE country_code IS NOT NULL
# MAGIC   AND indicator_id IS NOT NULL
# MAGIC   AND year IS NOT NULL;
# MAGIC   
# MAGIC -- Display data quality statistics
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_clean_records,
# MAGIC   COUNT(DISTINCT country_code) as unique_countries,
# MAGIC   COUNT(DISTINCT indicator_id) as unique_indicators,
# MAGIC   COUNT(DISTINCT year) as unique_years,
# MAGIC   COUNT(CASE WHEN value IS NOT NULL THEN 1 END) as records_with_values,
# MAGIC   COUNT(CASE WHEN value IS NULL THEN 1 END) as records_null_values,
# MAGIC   ROUND(COUNT(CASE WHEN value IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 2) as pct_with_values
# MAGIC FROM bronze_clean;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM bronze_clean

# COMMAND ----------

# DBTITLE 1,Create dim_country
# MAGIC %sql
# MAGIC -- MERGE dim_country - Incremental update with stable surrogate keys
# MAGIC -- Existing countries keep their keys; only new countries get new keys
# MAGIC
# MAGIC -- Step 1: Get distinct source data
# MAGIC CREATE OR REPLACE TEMP VIEW country_source_base AS
# MAGIC SELECT DISTINCT
# MAGIC   country_code,
# MAGIC   country_id,
# MAGIC   country_name,
# MAGIC   region_code,
# MAGIC   region_name,
# MAGIC   income_level_code,
# MAGIC   income_level_name,
# MAGIC   capital_city
# MAGIC FROM (
# MAGIC   SELECT *,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY country_code ORDER BY extraction_date DESC) AS rn
# MAGIC   FROM  bronze_clean
# MAGIC )
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC -- Step 2: Prepare complete source with surrogate keys (existing + new)
# MAGIC CREATE OR REPLACE TEMP VIEW country_source_with_keys AS
# MAGIC SELECT 
# MAGIC   COALESCE(t.country_key,
# MAGIC     (SELECT COALESCE(MAX(country_key), 0) FROM world_bank.silver.dim_country) + 
# MAGIC       ROW_NUMBER() OVER (PARTITION BY CASE WHEN t.country_key IS NULL THEN 1 ELSE 0 END 
# MAGIC                          ORDER BY s.country_code)
# MAGIC   ) as country_key,
# MAGIC   s.country_code,
# MAGIC   s.country_id,
# MAGIC   s.country_name,
# MAGIC   s.region_code,
# MAGIC   s.region_name,
# MAGIC   s.income_level_code,
# MAGIC   s.income_level_name,
# MAGIC   s.capital_city
# MAGIC FROM country_source_base s
# MAGIC LEFT JOIN world_bank.silver.dim_country t ON s.country_code = t.country_code;
# MAGIC
# MAGIC -- Step 3: MERGE into dim_country
# MAGIC MERGE INTO world_bank.silver.dim_country AS target
# MAGIC USING country_source_with_keys AS source
# MAGIC ON target.country_code = source.country_code 
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     country_id = source.country_id,
# MAGIC     country_name = source.country_name,
# MAGIC     region_code = source.region_code,
# MAGIC     region_name = source.region_name,
# MAGIC     income_level_code = source.income_level_code,
# MAGIC     income_level_name = source.income_level_name,
# MAGIC     capital_city = source.capital_city,
# MAGIC     updated_timestamp = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (country_key, country_code, country_id, country_name, region_code, region_name, income_level_code, income_level_name, capital_city, created_timestamp, updated_timestamp)
# MAGIC   VALUES (source.country_key, source.country_code, source.country_id, source.country_name, source.region_code, source.region_name, source.income_level_code, source.income_level_name, source.capital_city, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
# MAGIC
# MAGIC -- Verify dimension
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_countries,
# MAGIC   MIN(country_key) as min_key,
# MAGIC   MAX(country_key) as max_key,
# MAGIC   SUM(CASE WHEN DATE(updated_timestamp) = CURRENT_DATE() THEN 1 ELSE 0 END) as updated_today
# MAGIC FROM world_bank.silver.dim_country;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Create dim_indicator
# MAGIC %sql
# MAGIC -- MERGE dim_indicator - Incremental update with stable surrogate keys
# MAGIC -- Existing indicators keep their keys; only new indicators get new keys
# MAGIC
# MAGIC -- Step 1: Get distinct source data
# MAGIC CREATE OR REPLACE TEMP VIEW indicator_source_base AS
# MAGIC SELECT DISTINCT
# MAGIC   indicator_id,
# MAGIC   indicator_name,
# MAGIC   unit
# MAGIC FROM (    
# MAGIC     SELECT *,
# MAGIC           ROW_NUMBER() OVER (PARTITION BY indicator_id ORDER BY extraction_date DESC) AS rn
# MAGIC     FROM  bronze_clean
# MAGIC     ) t
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC -- Step 2: Prepare complete source with surrogate keys (existing + new)
# MAGIC CREATE OR REPLACE TEMP VIEW indicator_source_with_keys AS
# MAGIC SELECT 
# MAGIC   COALESCE(t.indicator_key,
# MAGIC     (SELECT COALESCE(MAX(indicator_key), 0) FROM world_bank.silver.dim_indicator) + 
# MAGIC       ROW_NUMBER() OVER (PARTITION BY CASE WHEN t.indicator_key IS NULL THEN 1 ELSE 0 END 
# MAGIC                          ORDER BY s.indicator_id)
# MAGIC   ) as indicator_key,
# MAGIC   s.indicator_id,
# MAGIC   s.indicator_name,
# MAGIC   s.unit
# MAGIC FROM indicator_source_base s
# MAGIC LEFT JOIN world_bank.silver.dim_indicator t ON s.indicator_id = t.indicator_id;
# MAGIC
# MAGIC -- Step 3: MERGE into dim_indicator
# MAGIC MERGE INTO world_bank.silver.dim_indicator AS target
# MAGIC USING indicator_source_with_keys AS source
# MAGIC ON target.indicator_id = source.indicator_id
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     indicator_name = source.indicator_name,
# MAGIC     unit = source.unit,
# MAGIC     updated_timestamp = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (indicator_key, indicator_id, indicator_name, unit, created_timestamp, updated_timestamp)
# MAGIC   VALUES (source.indicator_key, source.indicator_id, source.indicator_name, source.unit,
# MAGIC           CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
# MAGIC
# MAGIC -- Verify dimension
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_indicators,
# MAGIC   MIN(indicator_key) as min_key,
# MAGIC   MAX(indicator_key) as max_key,
# MAGIC   SUM(CASE WHEN DATE(updated_timestamp) = CURRENT_DATE() THEN 1 ELSE 0 END) as updated_today
# MAGIC FROM world_bank.silver.dim_indicator;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Create dim_date
# MAGIC %sql
# MAGIC -- MERGE dim_date - Incremental update with stable surrogate keys
# MAGIC -- Existing years keep their keys; only new years get new keys
# MAGIC
# MAGIC -- Step 1: Get distinct source data
# MAGIC CREATE OR REPLACE TEMP VIEW date_source_base AS
# MAGIC SELECT DISTINCT
# MAGIC   TO_DATE(CONCAT(year, '-01-01')) as date,
# MAGIC   CAST(year AS INT) as year,
# MAGIC   CAST((CAST(year AS INT) / 10) AS INT) * 10 as decade,
# MAGIC   (CAST(year AS INT) / 100) + 1 as century
# MAGIC FROM (    
# MAGIC     SELECT *,
# MAGIC           ROW_NUMBER() OVER (PARTITION BY year ORDER BY extraction_date DESC) AS rn
# MAGIC     FROM  bronze_clean
# MAGIC     ) t
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC -- Step 2: Prepare complete source with surrogate keys (existing + new)
# MAGIC CREATE OR REPLACE TEMP VIEW date_source_with_keys AS
# MAGIC SELECT 
# MAGIC   COALESCE(t.date_key,
# MAGIC     (SELECT COALESCE(MAX(date_key), 0) FROM world_bank.silver.dim_date) + 
# MAGIC       ROW_NUMBER() OVER (PARTITION BY CASE WHEN t.date_key IS NULL THEN 1 ELSE 0 END 
# MAGIC                          ORDER BY s.year)
# MAGIC   ) as date_key,
# MAGIC   s.date,
# MAGIC   s.year,
# MAGIC   s.decade,
# MAGIC   s.century
# MAGIC FROM date_source_base s
# MAGIC LEFT JOIN world_bank.silver.dim_date t ON s.year = t.year;
# MAGIC
# MAGIC -- Step 3: MERGE into dim_date
# MAGIC MERGE INTO world_bank.silver.dim_date AS target
# MAGIC USING date_source_with_keys AS source
# MAGIC ON target.year = source.year
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     date = source.date,
# MAGIC     decade = source.decade,
# MAGIC     century = source.century,
# MAGIC     updated_timestamp = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (date_key, date, year, decade, century, created_timestamp, updated_timestamp)
# MAGIC   VALUES (source.date_key, source.date, source.year, source.decade, source.century,
# MAGIC           CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
# MAGIC
# MAGIC -- Verify dimension
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_years,
# MAGIC   MIN(year) as earliest_year,
# MAGIC   MAX(year) as latest_year,
# MAGIC   MIN(date_key) as min_key,
# MAGIC   MAX(date_key) as max_key,
# MAGIC   SUM(CASE WHEN DATE(updated_timestamp) = CURRENT_DATE() THEN 1 ELSE 0 END) as updated_today
# MAGIC FROM world_bank.silver.dim_date;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Create fact_indicator_values
# MAGIC %sql
# MAGIC -- MERGE fact_indicator_values - Incremental update with stable surrogate keys
# MAGIC -- Match on natural key: (country_key, indicator_key, date_key)
# MAGIC
# MAGIC -- Step 1: Join bronze data with dimensions and get unique records
# MAGIC CREATE OR REPLACE TEMP VIEW fact_source_raw AS
# MAGIC SELECT 
# MAGIC   dc.country_key,
# MAGIC   di.indicator_key,
# MAGIC   dd.date_key,
# MAGIC   b.value,
# MAGIC   b.obs_status,
# MAGIC   b.decimal,
# MAGIC   b.extraction_timestamp,
# MAGIC   b.source,
# MAGIC   ROW_NUMBER() OVER (PARTITION BY dc.country_key, di.indicator_key, dd.date_key 
# MAGIC                      ORDER BY b.extraction_timestamp DESC) as rn
# MAGIC FROM bronze_clean b
# MAGIC INNER JOIN world_bank.silver.dim_country dc 
# MAGIC   ON b.country_code = dc.country_code
# MAGIC INNER JOIN world_bank.silver.dim_indicator di 
# MAGIC   ON b.indicator_id = di.indicator_id
# MAGIC INNER JOIN world_bank.silver.dim_date dd 
# MAGIC   ON CAST(b.year AS INT) = dd.year;
# MAGIC
# MAGIC -- Step 2: Keep only the most recent record per natural key
# MAGIC CREATE OR REPLACE TEMP VIEW fact_source_base AS
# MAGIC SELECT 
# MAGIC   country_key,
# MAGIC   indicator_key,
# MAGIC   date_key,
# MAGIC   value,
# MAGIC   obs_status,
# MAGIC   decimal,
# MAGIC   extraction_timestamp,
# MAGIC   source
# MAGIC FROM fact_source_raw
# MAGIC WHERE rn = 1;
# MAGIC
# MAGIC -- Step 3: Prepare complete source with surrogate keys (existing + new)
# MAGIC CREATE OR REPLACE TEMP VIEW fact_source_with_keys_raw AS
# MAGIC SELECT 
# MAGIC   COALESCE(t.fact_key,
# MAGIC     (SELECT COALESCE(MAX(fact_key), 0) FROM world_bank.silver.fact_indicator_values) + 
# MAGIC       ROW_NUMBER() OVER (PARTITION BY CASE WHEN t.fact_key IS NULL THEN 1 ELSE 0 END 
# MAGIC                          ORDER BY s.country_key, s.indicator_key, s.date_key)
# MAGIC   ) as fact_key,
# MAGIC   s.country_key,
# MAGIC   s.indicator_key,
# MAGIC   s.date_key,
# MAGIC   s.value,
# MAGIC   s.obs_status,
# MAGIC   s.decimal,
# MAGIC   s.extraction_timestamp,
# MAGIC   s.source
# MAGIC FROM fact_source_base s
# MAGIC LEFT JOIN world_bank.silver.fact_indicator_values t 
# MAGIC   ON s.country_key = t.country_key 
# MAGIC   AND s.indicator_key = t.indicator_key 
# MAGIC   AND s.date_key = t.date_key;
# MAGIC
# MAGIC -- Step 4: Final deduplication (keep first record per natural key)
# MAGIC CREATE OR REPLACE TEMP VIEW fact_source_with_keys AS
# MAGIC SELECT DISTINCT
# MAGIC   FIRST(fact_key) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as fact_key,
# MAGIC   country_key,
# MAGIC   indicator_key,
# MAGIC   date_key,
# MAGIC   FIRST(value) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as value,
# MAGIC   FIRST(obs_status) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as obs_status,
# MAGIC   FIRST(decimal) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as decimal,
# MAGIC   FIRST(extraction_timestamp) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as extraction_timestamp,
# MAGIC   FIRST(source) OVER (PARTITION BY country_key, indicator_key, date_key ORDER BY fact_key) as source
# MAGIC FROM fact_source_with_keys_raw;
# MAGIC
# MAGIC -- Step 5: MERGE into fact_indicator_values
# MAGIC MERGE INTO world_bank.silver.fact_indicator_values AS target
# MAGIC USING fact_source_with_keys AS source
# MAGIC ON target.country_key = source.country_key
# MAGIC    AND target.indicator_key = source.indicator_key
# MAGIC    AND target.date_key = source.date_key
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     value = source.value,
# MAGIC     obs_status = source.obs_status,
# MAGIC     decimal = source.decimal,
# MAGIC     extraction_timestamp = source.extraction_timestamp,
# MAGIC     source = source.source,
# MAGIC     updated_timestamp = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (fact_key, country_key, indicator_key, date_key, value, obs_status, decimal, 
# MAGIC           extraction_timestamp, source, created_timestamp, updated_timestamp)
# MAGIC   VALUES (source.fact_key, source.country_key, source.indicator_key, source.date_key, 
# MAGIC           source.value, source.obs_status, source.decimal, source.extraction_timestamp, 
# MAGIC           source.source, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
# MAGIC
# MAGIC -- Verify fact table
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_facts,
# MAGIC   COUNT(DISTINCT country_key) as unique_countries,
# MAGIC   COUNT(DISTINCT indicator_key) as unique_indicators,
# MAGIC   COUNT(DISTINCT date_key) as unique_dates,
# MAGIC   COUNT(CASE WHEN value IS NOT NULL THEN 1 END) as facts_with_values,
# MAGIC   MIN(fact_key) as min_key,
# MAGIC   MAX(fact_key) as max_key,
# MAGIC   SUM(CASE WHEN DATE(updated_timestamp) = CURRENT_DATE() THEN 1 ELSE 0 END) as updated_today
# MAGIC FROM world_bank.silver.fact_indicator_values;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Verify Transformations
# MAGIC %sql
# MAGIC -- Verify all tables and row counts
# MAGIC SELECT 'dim_country' as table_name, COUNT(*) as row_count FROM world_bank.silver.dim_country
# MAGIC UNION ALL
# MAGIC SELECT 'dim_indicator', COUNT(*) FROM world_bank.silver.dim_indicator
# MAGIC UNION ALL
# MAGIC SELECT 'dim_date', COUNT(*) FROM world_bank.silver.dim_date
# MAGIC UNION ALL
# MAGIC SELECT 'fact_indicator_values', COUNT(*) FROM world_bank.silver.fact_indicator_values;
# MAGIC
# MAGIC -- Verify referential integrity (all foreign keys exist in dimensions)
# MAGIC SELECT 
# MAGIC   'Referential Integrity Check' as check_name,
# MAGIC   COUNT(*) as total_facts,
# MAGIC   COUNT(DISTINCT f.country_key) as fact_countries,
# MAGIC   COUNT(DISTINCT c.country_key) as dim_countries,
# MAGIC   COUNT(DISTINCT f.indicator_key) as fact_indicators,
# MAGIC   COUNT(DISTINCT i.indicator_key) as dim_indicators,
# MAGIC   COUNT(DISTINCT f.date_key) as fact_dates,
# MAGIC   COUNT(DISTINCT d.date_key) as dim_dates,
# MAGIC   CASE 
# MAGIC     WHEN COUNT(DISTINCT f.country_key) = COUNT(DISTINCT c.country_key)
# MAGIC      AND COUNT(DISTINCT f.indicator_key) = COUNT(DISTINCT i.indicator_key)
# MAGIC      AND COUNT(DISTINCT f.date_key) = COUNT(DISTINCT d.date_key)
# MAGIC     THEN 'PASS ✓'
# MAGIC     ELSE 'FAIL ✗'
# MAGIC   END as integrity_status
# MAGIC FROM world_bank.silver.fact_indicator_values f
# MAGIC LEFT JOIN world_bank.silver.dim_country c ON f.country_key = c.country_key
# MAGIC LEFT JOIN world_bank.silver.dim_indicator i ON f.indicator_key = i.indicator_key
# MAGIC LEFT JOIN world_bank.silver.dim_date d ON f.date_key = d.date_key;
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Sample star schema query
# MAGIC %sql
# MAGIC -- Sample star schema query: GDP by country and year
# MAGIC SELECT 
# MAGIC   c.country_name,
# MAGIC   c.region_name,
# MAGIC   c.income_level_name,
# MAGIC   c.capital_city,
# MAGIC   d.year,
# MAGIC   i.indicator_name,
# MAGIC   ROUND(f.value / 1e9, 2) as value_billions_usd
# MAGIC FROM world_bank.silver.fact_indicator_values f
# MAGIC INNER JOIN world_bank.silver.dim_country c ON f.country_key = c.country_key
# MAGIC INNER JOIN world_bank.silver.dim_indicator i ON f.indicator_key = i.indicator_key
# MAGIC INNER JOIN world_bank.silver.dim_date d ON f.date_key = d.date_key
# MAGIC WHERE i.indicator_id = 'NY.GDP.MKTP.CD'
# MAGIC   AND d.year >= 2020
# MAGIC ORDER BY c.country_name, d.year
# MAGIC LIMIT 100;