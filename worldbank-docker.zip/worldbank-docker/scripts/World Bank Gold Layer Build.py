# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Title and Description
# MAGIC %md
# MAGIC # World Bank Data - Gold Layer
# MAGIC
# MAGIC **Purpose**: Creates denormalized, reporting-ready tables from Silver star schema for business users and reporting tools.
# MAGIC
# MAGIC **Gold Layer Tables**:
# MAGIC
# MAGIC 1. **gold_country_indicators** (Wide Format)
# MAGIC    - One row per country per year with all indicators as separate columns
# MAGIC    - Enables easy filtering and comparison across indicators
# MAGIC    - Optimized for country-level analysis and reporting
# MAGIC
# MAGIC 2. **gold_indicator_trends** (Time-Series Analysis)
# MAGIC    - Global statistics for each indicator over time
# MAGIC    - Includes mean, median, standard deviation, percentiles (25th, 75th)
# MAGIC    - Year-over-year change calculations
# MAGIC    - Enables trend analysis and forecasting
# MAGIC
# MAGIC 3. **gold_country_summary** (Data Quality Metrics)
# MAGIC    - Country-level data completeness scores
# MAGIC    - Tracks data availability across years and indicators
# MAGIC    - Helps identify data gaps and coverage issues
# MAGIC
# MAGIC **Architecture**: Bronze (raw) → Silver (star schema) → **Gold (denormalized reporting tables)**

# COMMAND ----------

# DBTITLE 1,Configuration
# Source configuration (Silver layer)
SOURCE_CATALOG = 'world_bank'
SOURCE_SCHEMA = 'silver'

# Silver tables
DIM_COUNTRY = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.dim_country"
DIM_INDICATOR = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.dim_indicator"
DIM_DATE = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.dim_date"
FACT_TABLE = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.fact_indicator_values"

# Target configuration (Gold layer)
TARGET_CATALOG = 'world_bank'
TARGET_SCHEMA = 'gold'

# Gold tables
GOLD_COUNTRY_INDICATORS = 'gold_country_indicators'
GOLD_INDICATOR_TRENDS = 'gold_indicator_trends'
GOLD_COUNTRY_SUMMARY = 'gold_country_summary'

print("Configuration loaded:")
print(f"  Source: {SOURCE_CATALOG}.{SOURCE_SCHEMA}")
print(f"  Target: {TARGET_CATALOG}.{TARGET_SCHEMA}")
print(f"  Gold tables:")
print(f"    - {GOLD_COUNTRY_INDICATORS} (wide format)")
print(f"    - {GOLD_INDICATOR_TRENDS} (time-series)")
print(f"    - {GOLD_COUNTRY_SUMMARY} (data quality)")

# COMMAND ----------

# DBTITLE 1,Create Gold Schema
# MAGIC %sql
# MAGIC -- Create Gold schema for denormalized reporting tables
# MAGIC CREATE SCHEMA IF NOT EXISTS world_bank.gold
# MAGIC COMMENT 'Gold layer: Denormalized, reporting-ready tables optimized for business users and BI tools';

# COMMAND ----------

# DBTITLE 1,Create gold_country_indicators (Wide Table)
# MAGIC %sql
# MAGIC -- Create wide table with all indicators as columns
# MAGIC -- Business purpose: Easy filtering and comparison across all indicators for a country/year
# MAGIC -- Use case: "Show me GDP, population, and life expectancy for USA in 2020"
# MAGIC CREATE OR REPLACE TABLE world_bank.gold.gold_country_indicators AS
# MAGIC SELECT 
# MAGIC   country_code,
# MAGIC   country_name,
# MAGIC   capital_city,
# MAGIC   region_name,
# MAGIC   income_level_name,
# MAGIC   year,
# MAGIC   date,
# MAGIC   decade,
# MAGIC   -- Pivot indicators into columns (using indicator_id as column names)
# MAGIC   MAX(CASE WHEN indicator_id = 'NY.GDP.MKTP.CD' THEN value END) as gdp_current_usd,
# MAGIC   MAX(CASE WHEN indicator_id = 'SP.POP.TOTL' THEN value END) as population_total,
# MAGIC   MAX(CASE WHEN indicator_id = 'NY.GDP.PCAP.CD' THEN value END) as gdp_per_capita_usd,
# MAGIC   MAX(CASE WHEN indicator_id = 'SP.DYN.LE00.IN' THEN value END) as life_expectancy_years,
# MAGIC   MAX(CASE WHEN indicator_id = 'SE.XPD.TOTL.GD.ZS' THEN value END) as education_expenditure_pct_gdp,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM (
# MAGIC   SELECT 
# MAGIC     dc.country_code,
# MAGIC     dc.country_name,
# MAGIC     dc.capital_city,
# MAGIC     dc.region_name,
# MAGIC     dc.income_level_name,
# MAGIC     dd.year,
# MAGIC     dd.date,
# MAGIC     dd.decade,
# MAGIC     di.indicator_id,
# MAGIC     f.value
# MAGIC   FROM world_bank.silver.fact_indicator_values f
# MAGIC   INNER JOIN world_bank.silver.dim_country dc ON f.country_key = dc.country_key
# MAGIC   INNER JOIN world_bank.silver.dim_indicator di ON f.indicator_key = di.indicator_key
# MAGIC   INNER JOIN world_bank.silver.dim_date dd ON f.date_key = dd.date_key
# MAGIC )
# MAGIC GROUP BY country_code, country_name, capital_city, region_name, income_level_name, year, date, decade
# MAGIC ORDER BY country_code, year;
# MAGIC
# MAGIC -- Verify table creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_rows,
# MAGIC   COUNT(DISTINCT country_code) as unique_countries,
# MAGIC   COUNT(DISTINCT region_name) as unique_regions,
# MAGIC   COUNT(DISTINCT income_level_name) as unique_income_levels,
# MAGIC   COUNT(DISTINCT year) as unique_years,
# MAGIC   MIN(year) as earliest_year,
# MAGIC   MAX(year) as latest_year,
# MAGIC   MAX(date) as latest_date
# MAGIC FROM world_bank.gold.gold_country_indicators;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample records showing wide format
# MAGIC SELECT * FROM world_bank.gold.gold_country_indicators LIMIT 5;

# COMMAND ----------

# DBTITLE 1,Create gold_indicator_trends (Time-Series)
# MAGIC %sql
# MAGIC -- Create time-series trends with global statistics
# MAGIC -- Business purpose: Analyze how indicators change over time globally
# MAGIC -- Use case: "Show me the global trend for life expectancy with year-over-year changes"
# MAGIC CREATE OR REPLACE TABLE world_bank.gold.gold_indicator_trends AS
# MAGIC WITH indicator_stats AS (
# MAGIC   SELECT 
# MAGIC     dd.year,
# MAGIC     dd.decade,
# MAGIC     di.indicator_id,
# MAGIC     di.indicator_name,
# MAGIC     di.unit,
# MAGIC     COUNT(f.value) as country_count,
# MAGIC     AVG(f.value) as global_mean,
# MAGIC     STDDEV(f.value) as global_stddev,
# MAGIC     MIN(f.value) as global_min,
# MAGIC     MAX(f.value) as global_max,
# MAGIC     PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY f.value) as global_p25,
# MAGIC     PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY f.value) as global_median,
# MAGIC     PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY f.value) as global_p75
# MAGIC   FROM world_bank.silver.fact_indicator_values f
# MAGIC   INNER JOIN world_bank.silver.dim_indicator di ON f.indicator_key = di.indicator_key
# MAGIC   INNER JOIN world_bank.silver.dim_date dd ON f.date_key = dd.date_key
# MAGIC   WHERE f.value IS NOT NULL
# MAGIC   GROUP BY dd.year, dd.decade, di.indicator_id, di.indicator_name, di.unit
# MAGIC )
# MAGIC SELECT 
# MAGIC   year,
# MAGIC   decade,
# MAGIC   indicator_id,
# MAGIC   indicator_name,
# MAGIC   unit,
# MAGIC   country_count,
# MAGIC   ROUND(global_mean, 2) as global_mean,
# MAGIC   ROUND(global_median, 2) as global_median,
# MAGIC   ROUND(global_stddev, 2) as global_stddev,
# MAGIC   ROUND(global_min, 2) as global_min,
# MAGIC   ROUND(global_max, 2) as global_max,
# MAGIC   ROUND(global_p25, 2) as global_p25,
# MAGIC   ROUND(global_p75, 2) as global_p75,
# MAGIC   -- Calculate year-over-year change
# MAGIC   ROUND(global_mean - LAG(global_mean, 1) OVER (PARTITION BY indicator_id ORDER BY year), 2) as yoy_change,
# MAGIC   ROUND(
# MAGIC     ((global_mean - LAG(global_mean, 1) OVER (PARTITION BY indicator_id ORDER BY year)) / 
# MAGIC      LAG(global_mean, 1) OVER (PARTITION BY indicator_id ORDER BY year) * 100),
# MAGIC     2
# MAGIC   ) as yoy_change_pct,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM indicator_stats
# MAGIC ORDER BY indicator_id, year;
# MAGIC
# MAGIC -- Verify table creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_rows,
# MAGIC   COUNT(DISTINCT indicator_id) as unique_indicators,
# MAGIC   COUNT(DISTINCT year) as unique_years
# MAGIC FROM world_bank.gold.gold_indicator_trends;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample trend data
# MAGIC SELECT 
# MAGIC   year,
# MAGIC   indicator_name,
# MAGIC   country_count,
# MAGIC   global_mean,
# MAGIC   global_median,
# MAGIC   yoy_change,
# MAGIC   yoy_change_pct
# MAGIC FROM world_bank.gold.gold_indicator_trends
# MAGIC WHERE indicator_id = 'SP.DYN.LE00.IN' -- Life expectancy
# MAGIC ORDER BY year
# MAGIC LIMIT 10;

# COMMAND ----------

# DBTITLE 1,Create gold_country_summary (Data Quality)
# MAGIC %sql
# MAGIC -- Create country-level data quality summary
# MAGIC -- Business purpose: Identify data completeness and coverage gaps
# MAGIC -- Use case: "Which countries have the most complete data?"
# MAGIC CREATE OR REPLACE TABLE world_bank.gold.gold_country_summary AS
# MAGIC WITH country_stats AS (
# MAGIC   SELECT 
# MAGIC     dc.country_code,
# MAGIC     dc.country_name,
# MAGIC     dc.region_code,
# MAGIC     dc.region_name,
# MAGIC     dc.income_level_code,
# MAGIC     dc.income_level_name,
# MAGIC     MIN(dd.year) as first_year,
# MAGIC     MAX(dd.year) as last_year,
# MAGIC     COUNT(DISTINCT dd.year) as year_count,
# MAGIC     COUNT(DISTINCT di.indicator_id) as indicator_count,
# MAGIC     COUNT(f.value) as total_data_points
# MAGIC   FROM world_bank.silver.fact_indicator_values f
# MAGIC   INNER JOIN world_bank.silver.dim_country dc ON f.country_key = dc.country_key
# MAGIC   INNER JOIN world_bank.silver.dim_indicator di ON f.indicator_key = di.indicator_key
# MAGIC   INNER JOIN world_bank.silver.dim_date dd ON f.date_key = dd.date_key
# MAGIC   WHERE f.value IS NOT NULL
# MAGIC   GROUP BY 
# MAGIC     dc.country_code, 
# MAGIC     dc.country_name,  
# MAGIC     dc.region_code,
# MAGIC     dc.region_name,
# MAGIC     dc.income_level_code,
# MAGIC     dc.income_level_name
# MAGIC ),
# MAGIC max_possible AS (
# MAGIC   SELECT 
# MAGIC     MAX(indicator_count) as max_indicators,
# MAGIC     MAX(year_count) as max_years
# MAGIC   FROM country_stats
# MAGIC )
# MAGIC SELECT 
# MAGIC   cs.country_code,
# MAGIC   cs.country_name,
# MAGIC   cs.first_year,
# MAGIC   cs.last_year,
# MAGIC   cs.year_count,
# MAGIC   cs.indicator_count,
# MAGIC   cs.total_data_points,
# MAGIC   (mp.max_indicators * mp.max_years) as max_possible_points,
# MAGIC   ROUND((cs.total_data_points * 100.0 / (mp.max_indicators * mp.max_years)), 2) as completeness_score,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM country_stats cs
# MAGIC CROSS JOIN max_possible mp
# MAGIC ORDER BY completeness_score DESC;
# MAGIC
# MAGIC -- Verify table creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_countries,
# MAGIC   ROUND(AVG(completeness_score), 2) as avg_completeness_score,
# MAGIC   ROUND(MIN(completeness_score), 2) as min_completeness_score,
# MAGIC   ROUND(MAX(completeness_score), 2) as max_completeness_score
# MAGIC FROM world_bank.gold.gold_country_summary;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample data quality scores
# MAGIC SELECT * FROM world_bank.gold.gold_country_summary LIMIT 10;

# COMMAND ----------

# DBTITLE 1,Verify Gold Tables
# MAGIC %sql
# MAGIC -- Verify all Gold tables created successfully
# MAGIC SELECT 'gold_country_indicators' as table_name, COUNT(*) as row_count 
# MAGIC FROM world_bank.gold.gold_country_indicators
# MAGIC UNION ALL
# MAGIC SELECT 'gold_indicator_trends', COUNT(*) 
# MAGIC FROM world_bank.gold.gold_indicator_trends
# MAGIC UNION ALL
# MAGIC SELECT 'gold_country_summary', COUNT(*) 
# MAGIC FROM world_bank.gold.gold_country_summary;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample from gold_country_indicators (wide format)
# MAGIC SELECT 
# MAGIC   country_name,
# MAGIC   region_name,
# MAGIC   income_level_name,
# MAGIC   year,
# MAGIC   ROUND(gdp_current_usd / 1e9, 2) as gdp_billions_usd,
# MAGIC   ROUND(population_total / 1e6, 2) as population_millions,
# MAGIC   ROUND(gdp_per_capita_usd, 2) as gdp_per_capita,
# MAGIC   ROUND(life_expectancy_years, 1) as life_expectancy,
# MAGIC   ROUND(education_expenditure_pct_gdp, 2) as edu_pct_gdp
# MAGIC FROM world_bank.gold.gold_country_indicators
# MAGIC WHERE year >= 2020
# MAGIC ORDER BY country_name, year
# MAGIC LIMIT 10;

# COMMAND ----------

# DBTITLE 1,Sample Analytical Queries
# MAGIC %sql
# MAGIC -- Example 1: GDP and Population for USA over time
# MAGIC SELECT 
# MAGIC   year,
# MAGIC   ROUND(gdp_current_usd / 1e12, 2) as gdp_trillions_usd,
# MAGIC   ROUND(population_total / 1e6, 2) as population_millions,
# MAGIC   ROUND(gdp_per_capita_usd, 0) as gdp_per_capita
# MAGIC FROM world_bank.gold.gold_country_indicators
# MAGIC WHERE country_code = 'USA'
# MAGIC ORDER BY year;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Example 2: Global life expectancy trends with year-over-year changes
# MAGIC SELECT 
# MAGIC   year,
# MAGIC   indicator_name,
# MAGIC   country_count,
# MAGIC   ROUND(global_mean, 2) as avg_life_expectancy,
# MAGIC   ROUND(global_median, 2) as median_life_expectancy,
# MAGIC   ROUND(yoy_change, 2) as yoy_change_years,
# MAGIC   ROUND(yoy_change_pct, 2) as yoy_change_percent
# MAGIC FROM world_bank.gold.gold_indicator_trends
# MAGIC WHERE indicator_id = 'SP.DYN.LE00.IN'
# MAGIC ORDER BY year;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Example 3: Countries ranked by data completeness
# MAGIC SELECT 
# MAGIC   country_name,
# MAGIC   year_count as years_with_data,
# MAGIC   indicator_count as indicators_available,
# MAGIC   total_data_points,
# MAGIC   completeness_score as score_pct,
# MAGIC   CASE 
# MAGIC     WHEN completeness_score >= 90 THEN '⭐⭐⭐ Excellent'
# MAGIC     WHEN completeness_score >= 70 THEN '⭐⭐ Good'
# MAGIC     WHEN completeness_score >= 50 THEN '⭐ Fair'
# MAGIC     ELSE '⚠️ Limited'
# MAGIC   END as data_quality_rating
# MAGIC FROM world_bank.gold.gold_country_summary
# MAGIC ORDER BY completeness_score DESC;