# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Pipeline Overview
# MAGIC %md
# MAGIC # World Bank Lakehouse Pipeline Orchestrator
# MAGIC
# MAGIC This notebook orchestrates the full ETL pipeline across three layers:
# MAGIC
# MAGIC * **Bronze Layer**: Raw data extraction from World Bank API
# MAGIC * **Silver Layer**: Star schema transformation (dimensions and facts)
# MAGIC * **Gold Layer**: Denormalized reporting tables for analytics
# MAGIC
# MAGIC The pipeline executes sequentially, ensuring each stage completes successfully before proceeding to the next.

# COMMAND ----------

# DBTITLE 1,Configuration and Setup
# Configuration and Setup
from datetime import datetime
import time

# Create widgets for pipeline configuration
dbutils.widgets.text("catalog", "world_bank", "Unity Catalog")
dbutils.widgets.text("date_from", "2010", "Date From (year)")
dbutils.widgets.text("date_to", "2023", "Date To (year)")

# Get widget values
catalog = dbutils.widgets.get("catalog")
date_from = dbutils.widgets.get("date_from")
date_to = dbutils.widgets.get("date_to")

# Track pipeline execution time
pipeline_start = time.time()
start_timestamp = datetime.now()

print("=" * 70)
print("  WORLD BANK LAKEHOUSE PIPELINE - STARTING".center(70))
print("=" * 70)
print(f"Started at: {start_timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"\nConfiguration:")
print(f"  Catalog:    {catalog}")
print(f"  Date Range: {date_from} - {date_to}")
print("=" * 70)

# COMMAND ----------

# DBTITLE 1,Stage 1: Bronze Layer
# MAGIC %md
# MAGIC ## Stage 1: Bronze Layer - Data Extraction
# MAGIC
# MAGIC Extracts raw data from the World Bank API and stores it in Delta tables.

# COMMAND ----------

# DBTITLE 1,Run Bronze Extraction
# Execute Bronze Layer extraction
print("\n" + "=" * 70)
print("  BRONZE LAYER - Data Extraction".center(70))
print("=" * 70)

bronze_start = time.time()

try:
    result = dbutils.notebook.run(
        "/Users/tienie.nothnagel@engenoil.com/worldbank-docker/scripts/World Bank Bronze Extraction",
        timeout_seconds=1800,
        arguments={
            "catalog": catalog,
            "date_from": date_from,
            "date_to": date_to
        }
    )
    
    bronze_elapsed = time.time() - bronze_start
    print(f"\n✓ Bronze layer completed successfully in {bronze_elapsed:.2f} seconds ({bronze_elapsed/60:.2f} minutes)")
    print("=" * 70)
    
except Exception as e:
    bronze_elapsed = time.time() - bronze_start
    print(f"\n✗ Bronze layer failed after {bronze_elapsed:.2f} seconds")
    print(f"Error: {e}")
    print("=" * 70)
    raise

# COMMAND ----------

# DBTITLE 1,Stage 2: Silver Layer
# MAGIC %md
# MAGIC ## Stage 2: Silver Layer - Star Schema Transformation
# MAGIC
# MAGIC Transforms raw data into a star schema with dimension and fact tables.

# COMMAND ----------

# DBTITLE 1,Run Silver Transformation
# Execute Silver Layer transformation
print("\n" + "=" * 70)
print("  SILVER LAYER - Star Schema Transformation".center(70))
print("=" * 70)

silver_start = time.time()

try:
    result = dbutils.notebook.run(
        "/Users/tienie.nothnagel@engenoil.com/worldbank-docker/scripts/World Bank Silver Transformation",
        timeout_seconds=1200,
        arguments={
            "catalog": catalog
        }
    )
    

    silver_elapsed = time.time() - silver_start
    print(f"\n✓ Silver layer completed successfully in {silver_elapsed:.2f} seconds ({silver_elapsed/60:.2f} minutes)")
    print("=" * 70)
    
except Exception as e:
    silver_elapsed = time.time() - silver_start
    print(f"\n✗ Silver layer failed after {silver_elapsed:.2f} seconds")
    print(f"Error: {e}")
    print("=" * 70)
    raise

# COMMAND ----------

# DBTITLE 1,Stage 3: Gold Layer
# MAGIC %md
# MAGIC ## Stage 3: Gold Layer - Reporting Tables
# MAGIC
# MAGIC Creates denormalized reporting tables optimized for analytics and dashboards.

# COMMAND ----------

# DBTITLE 1,Run Gold Layer Build
# Execute Gold Layer build
print("\n" + "=" * 70)
print("  GOLD LAYER - Reporting Tables".center(70))
print("=" * 70)

gold_start = time.time()

try:
    result = dbutils.notebook.run(
        "/Users/tienie.nothnagel@engenoil.com/worldbank-docker/scripts/World Bank Gold Layer Build",
        timeout_seconds=1200,
        arguments={
            "catalog": catalog
        }
    )
    
    gold_elapsed = time.time() - gold_start
    print(f"\n✓ Gold layer completed successfully in {gold_elapsed:.2f} seconds ({gold_elapsed/60:.2f} minutes)")
    print("=" * 70)
    
except Exception as e:
    gold_elapsed = time.time() - gold_start
    print(f"\n✗ Gold layer failed after {gold_elapsed:.2f} seconds")
    print(f"Error: {e}")
    print("=" * 70)
    raise

# COMMAND ----------

# DBTITLE 1,Pipeline Summary
# MAGIC %md
# MAGIC ## Pipeline Summary
# MAGIC
# MAGIC Complete execution summary and timing information.

# COMMAND ----------

# DBTITLE 1,Summary and Completion
# Pipeline Summary and Completion
total_elapsed = time.time() - pipeline_start
end_timestamp = datetime.now()

print("\n" + "#" * 70)
print("#" + " " * 68 + "#")
print("#" + "  PIPELINE COMPLETED SUCCESSFULLY!".center(68) + "#")
print("#" + " " * 68 + "#")
print("#" * 70)
print(f"\nPipeline Execution Summary:")
print(f"  Started:        {start_timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"  Completed:      {end_timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"  Total Duration: {total_elapsed:.2f} seconds ({total_elapsed/60:.2f} minutes)")
print(f"\nStages Completed:")
print(f"  ✓ Bronze Layer  - Data Extraction")
print(f"  ✓ Silver Layer  - Star Schema Transformation")
print(f"  ✓ Gold Layer    - Reporting Tables")
print(f"\nCatalog: {catalog}")
print(f"Date Range: {date_from} - {date_to}")
print("#" * 70)