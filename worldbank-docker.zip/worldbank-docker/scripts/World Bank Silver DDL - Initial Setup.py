# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,Overview
# MAGIC %md
# MAGIC # World Bank Silver Layer - DDL Initial Setup
# MAGIC
# MAGIC **Purpose**: First-time creation of Silver layer dimension and fact tables.
# MAGIC
# MAGIC **Usage**: Run this notebook ONCE to create the initial table structures with surrogate keys.
# MAGIC
# MAGIC ⚠️ **Important**: This notebook uses `CREATE OR REPLACE TABLE` which will drop existing data.
# MAGIC
# MAGIC **Tables Created**:
# MAGIC * **dim_country**: Country dimension with surrogate keys
# MAGIC * **dim_indicator**: Indicator dimension with surrogate keys  
# MAGIC * **dim_date**: Date dimension with surrogate keys
# MAGIC * **fact_indicator_values**: Central fact table with foreign keys
# MAGIC
# MAGIC **After Running This**:
# MAGIC Use the "World Bank Silver Transformation" notebook for incremental updates with MERGE logic.

# COMMAND ----------

# DBTITLE 1,Configuration
# Source configuration
SOURCE_CATALOG = 'world_bank'
SOURCE_SCHEMA = 'bronze'
SOURCE_TABLE = 'indicators'

# Target configuration
TARGET_CATALOG = 'world_bank'
TARGET_SCHEMA = 'silver'

# Full paths
source_table = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{SOURCE_TABLE}"
target_schema = f"{TARGET_CATALOG}.{TARGET_SCHEMA}"

print(f"DDL Configuration:")
print(f"  Source: {source_table}")
print(f"  Target schema: {target_schema}")
print(f"\n⚠️  This will CREATE OR REPLACE all Silver tables")

# COMMAND ----------

# DBTITLE 1,Create Silver Schema
# MAGIC %sql
# MAGIC -- Create Silver schema for star schema tables
# MAGIC CREATE SCHEMA IF NOT EXISTS world_bank.silver
# MAGIC COMMENT 'Silver layer: Star schema for World Bank data with dimensions and fact tables';

# COMMAND ----------

# DBTITLE 1,Read Bronze Data
# MAGIC %sql
# MAGIC -- Create temp view of clean bronze data
# MAGIC CREATE OR REPLACE TEMP VIEW bronze_clean AS
# MAGIC SELECT *
# MAGIC FROM  world_bank.bronze.indicators
# MAGIC WHERE country_code IS NOT NULL
# MAGIC   AND indicator_id IS NOT NULL
# MAGIC   AND year IS NOT NULL;
# MAGIC
# MAGIC -- Display data quality statistics
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_clean_records,
# MAGIC   COUNT(DISTINCT country_code) as unique_countries,
# MAGIC   COUNT(DISTINCT indicator_id) as unique_indicators,
# MAGIC   COUNT(DISTINCT year) as unique_years
# MAGIC FROM bronze_clean;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM bronze_clean

# COMMAND ----------

# DBTITLE 1,CREATE OR REPLACE dim_country
# MAGIC %sql
# MAGIC -- Create country dimension table
# MAGIC -- Surrogate key (country_key) enables efficient joins and insulates from source changes
# MAGIC CREATE OR REPLACE TABLE world_bank.silver.dim_country AS
# MAGIC SELECT 
# MAGIC   ROW_NUMBER() OVER (ORDER BY country_code) as country_key,
# MAGIC   country_code,
# MAGIC   country_id,
# MAGIC   country_name,
# MAGIC   capital_city,
# MAGIC   region_code,
# MAGIC   region_name,
# MAGIC   income_level_code,
# MAGIC   income_level_name,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM (
# MAGIC   SELECT DISTINCT
# MAGIC     country_code,
# MAGIC     country_id,
# MAGIC     country_name,
# MAGIC     capital_city,
# MAGIC     region_code,
# MAGIC     region_name,
# MAGIC     income_level_code,
# MAGIC     income_level_name,
# MAGIC                ROW_NUMBER() OVER (PARTITION BY country_code ORDER BY extraction_date DESC) AS rn
# MAGIC   FROM  bronze_clean
# MAGIC     ) t
# MAGIC     WHERE rn = 1;
# MAGIC
# MAGIC -- Verify dimension creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_countries,
# MAGIC   MIN(country_key) as min_key,
# MAGIC   MAX(country_key) as max_key
# MAGIC FROM world_bank.silver.dim_country;

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC FROM world_bank.silver.dim_country;

# COMMAND ----------

# DBTITLE 1,CREATE OR REPLACE dim_indicator
# MAGIC %sql
# MAGIC -- Create indicator dimension table
# MAGIC -- Stores metadata about each World Bank indicator
# MAGIC CREATE OR REPLACE TABLE world_bank.silver.dim_indicator AS
# MAGIC SELECT 
# MAGIC   ROW_NUMBER() OVER (ORDER BY indicator_id) as indicator_key,
# MAGIC   indicator_id,
# MAGIC   indicator_name,
# MAGIC   unit,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM (
# MAGIC   SELECT DISTINCT
# MAGIC     indicator_id,
# MAGIC     indicator_name,
# MAGIC     unit,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY indicator_id ORDER BY extraction_date DESC) AS rn
# MAGIC   FROM  bronze_clean
# MAGIC     ) t
# MAGIC   WHERE rn = 1;
# MAGIC
# MAGIC -- Verify dimension creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_indicators,
# MAGIC   MIN(indicator_key) as min_key,
# MAGIC   MAX(indicator_key) as max_key
# MAGIC FROM world_bank.silver.dim_indicator;

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC FROM world_bank.silver.dim_indicator;

# COMMAND ----------

# DBTITLE 1,CREATE OR REPLACE dim_date
# MAGIC %sql
# MAGIC -- Create date dimension table
# MAGIC -- Enables time-based analysis (year, decade, century)
# MAGIC CREATE OR REPLACE TABLE world_bank.silver.dim_date AS
# MAGIC SELECT 
# MAGIC   ROW_NUMBER() OVER (ORDER BY year) as date_key,
# MAGIC   date,
# MAGIC   year,
# MAGIC   decade,
# MAGIC   century,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM (
# MAGIC   SELECT DISTINCT
# MAGIC     TO_DATE(CONCAT(year, '-01-01')) as date,
# MAGIC     CAST(year AS INT) as year,
# MAGIC     CAST((CAST(year AS INT) / 10) AS INT) * 10 as decade,
# MAGIC     (CAST(year AS INT) / 100) + 1 as century,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY year ORDER BY extraction_date DESC) AS rn
# MAGIC   FROM  bronze_clean
# MAGIC     ) t
# MAGIC   WHERE rn = 1;
# MAGIC
# MAGIC -- Verify dimension creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_years,
# MAGIC   MIN(year) as earliest_year,
# MAGIC   MAX(year) as latest_year,
# MAGIC   MIN(date_key) as min_key,
# MAGIC   MAX(date_key) as max_key
# MAGIC FROM world_bank.silver.dim_date;

# COMMAND ----------

# DBTITLE 1,CREATE OR REPLACE fact_indicator_values
# MAGIC %sql
# MAGIC -- Create fact table with indicator values
# MAGIC -- Joins bronze data with all dimensions to get surrogate keys
# MAGIC -- Partitioned by date_key for query performance
# MAGIC CREATE OR REPLACE TABLE world_bank.silver.fact_indicator_values
# MAGIC PARTITIONED BY (date_key)
# MAGIC AS
# MAGIC SELECT 
# MAGIC   ROW_NUMBER() OVER (ORDER BY dc.country_key, di.indicator_key, dd.date_key) as fact_key,
# MAGIC   MAX(dc.country_key) AS country_key,
# MAGIC   MAX(di.indicator_key) AS indicator_key,
# MAGIC   MAX(dd.date_key) AS date_key,
# MAGIC   MAX(b.value) AS value,
# MAGIC   MAX(b.obs_status) AS obs_status,
# MAGIC   MAX(b.decimal) AS decimal,
# MAGIC   MAX(b.extraction_timestamp) AS extraction_timestamp,
# MAGIC   MAX(b.source) AS source,
# MAGIC   CURRENT_TIMESTAMP() as created_timestamp,
# MAGIC   CURRENT_TIMESTAMP() as updated_timestamp
# MAGIC FROM bronze_clean b
# MAGIC INNER JOIN world_bank.silver.dim_country dc 
# MAGIC   ON b.country_code = dc.country_code
# MAGIC INNER JOIN world_bank.silver.dim_indicator di 
# MAGIC   ON b.indicator_id = di.indicator_id
# MAGIC INNER JOIN world_bank.silver.dim_date dd 
# MAGIC   ON CAST(b.year AS INT) = dd.year
# MAGIC GROUP BY dc.country_key, di.indicator_key, dd.date_key
# MAGIC ORDER BY fact_key;
# MAGIC
# MAGIC -- Verify fact table creation
# MAGIC SELECT 
# MAGIC   COUNT(*) as total_facts,
# MAGIC   COUNT(DISTINCT country_key) as unique_countries,
# MAGIC   COUNT(DISTINCT indicator_key) as unique_indicators,
# MAGIC   COUNT(DISTINCT date_key) as unique_dates,
# MAGIC   COUNT(CASE WHEN value IS NOT NULL THEN 1 END) as facts_with_values,
# MAGIC   MIN(fact_key) as min_key,
# MAGIC   MAX(fact_key) as max_key
# MAGIC FROM world_bank.silver.fact_indicator_values;

# COMMAND ----------

# DBTITLE 1,Verification Summary
# MAGIC %sql
# MAGIC -- Verify all tables and row counts
# MAGIC SELECT 'dim_country' as table_name, COUNT(*) as row_count FROM world_bank.silver.dim_country
# MAGIC UNION ALL
# MAGIC SELECT 'dim_indicator', COUNT(*) FROM world_bank.silver.dim_indicator
# MAGIC UNION ALL
# MAGIC SELECT 'dim_date', COUNT(*) FROM world_bank.silver.dim_date
# MAGIC UNION ALL
# MAGIC SELECT 'fact_indicator_values', COUNT(*) FROM world_bank.silver.fact_indicator_values;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Sample star schema query: GDP by country and year
# MAGIC SELECT 
# MAGIC   c.country_name,
# MAGIC   c.country_code,
# MAGIC   c.capital_city,
# MAGIC   c.region_name,
# MAGIC   c.income_level_name,
# MAGIC   d.year,
# MAGIC   i.indicator_name,
# MAGIC   ROUND(f.value / 1e9, 2) as value_billions_usd
# MAGIC FROM world_bank.silver.fact_indicator_values f
# MAGIC INNER JOIN world_bank.silver.dim_country c ON f.country_key = c.country_key
# MAGIC INNER JOIN world_bank.silver.dim_indicator i ON f.indicator_key = i.indicator_key
# MAGIC INNER JOIN world_bank.silver.dim_date d ON f.date_key = d.date_key
# MAGIC WHERE i.indicator_id = 'NY.GDP.MKTP.CD'
# MAGIC   AND d.year >= 2020
# MAGIC ORDER BY c.country_name, d.year
# MAGIC LIMIT 200;