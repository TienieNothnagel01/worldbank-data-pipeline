# Databricks notebook source
# MAGIC %md
# MAGIC # World Bank Bronze Extraction
# MAGIC
# MAGIC ## Overview
# MAGIC This notebook extracts data from the World Bank API and creates structured bronze layer tables with **country hierarchy integration**.
# MAGIC
# MAGIC ## Architecture
# MAGIC
# MAGIC ### Bronze Layer Tables
# MAGIC
# MAGIC 1. **`countries`** (Dimension Table with Hierarchy)
# MAGIC    * Country basic information (ID, name, ISO codes)
# MAGIC    * **Geographic hierarchy**: region (e.g., Sub-Saharan Africa, East Asia & Pacific)
# MAGIC    * **Economic hierarchy**: income level (High income, Upper middle income, etc.)
# MAGIC    * **Institutional hierarchy**: lending type (IBRD, IDA, etc.)
# MAGIC    * Capital city, coordinates
# MAGIC
# MAGIC 2. **`indicators`** (Fact Table - Enriched)
# MAGIC    * All World Bank indicators (GDP, population, life expectancy, etc.)
# MAGIC    * **Enriched with country hierarchy** - includes region, income level, lending type
# MAGIC    * Enables multi-dimensional analysis without joins
# MAGIC    * Partitioned by extraction_date for incremental updates
# MAGIC
# MAGIC 3. **`raw_*` tables** (Audit/Replay)
# MAGIC    * Raw JSON payloads from API
# MAGIC    * For audit trails and data replay
# MAGIC
# MAGIC ## Key Features
# MAGIC
# MAGIC * **Country Hierarchy**: All indicators are automatically enriched with geographic and economic dimensions
# MAGIC * **Unified Structure**: Single indicators table instead of separate tables per indicator
# MAGIC * **Incremental Load**: Partitioned by extraction_date for efficient updates
# MAGIC * **Raw Audit Trail**: Original JSON preserved for traceability
# MAGIC
# MAGIC ## Usage
# MAGIC
# MAGIC Run the extraction cell to fetch data for the specified date range. The enriched indicators table enables analyses like:
# MAGIC * Compare GDP growth across regions
# MAGIC * Analyze life expectancy by income level
# MAGIC * Track education expenditure by lending type
# MAGIC * Aggregate any indicator by geographic or economic hierarchy
# MAGIC
# MAGIC ## Example Queries
# MAGIC
# MAGIC See the SQL cells below for examples of:
# MAGIC 1. Viewing country hierarchy
# MAGIC 2. Querying enriched indicators
# MAGIC 3. Aggregating by region and income level

# COMMAND ----------

# DBTITLE 1,Enhanced Bronze Extraction with Country Hierarchy
# Databricks Notebook: World Bank Bronze Extraction
# Layer : Bronze (Raw Landing + Parsed Dimensions)
# Purpose: Fetch World Bank API data with pagination and create structured bronze tables
#          including country hierarchy dimension and unified indicators fact table

import requests, json
from datetime import datetime, date
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StringType, StructType, StructField, DoubleType, IntegerType, DateType
)
from pyspark.sql.functions import (
    col, lit, from_json, get_json_object, current_timestamp, to_date
)

spark = SparkSession.builder.getOrCreate()

# ── Widgets (set defaults or override at runtime) ──────────────────────────
dbutils.widgets.text("date_from", "2010",       "Date From (year)")
dbutils.widgets.text("date_to",   "2023",       "Date To (year)")
dbutils.widgets.text("catalog",   "world_bank",  "Unity Catalog name")
dbutils.widgets.text("schema",    "bronze",     "Schema")

DATE_FROM = dbutils.widgets.get("date_from")
DATE_TO   = dbutils.widgets.get("date_to")
CATALOG   = dbutils.widgets.get("catalog")
SCHEMA    = dbutils.widgets.get("schema")
BASE      = "https://api.worldbank.org/v2"
RUN_TS    = datetime.utcnow().isoformat()
RUN_DATE  = date.today()

print(f"="*80)
print(f"World Bank Bronze Extraction")
print(f"Date Range: {DATE_FROM} - {DATE_TO}")
print(f"Target: {CATALOG}.{SCHEMA}")
print(f"Run Timestamp: {RUN_TS}")
print(f"="*80)

# ── Helper: paginated fetch ─────────────────────────────────────────────────
def fetch_all_pages(url: str, extra_params: dict = None) -> list:
    """Retrieve every page from a World Bank paginated endpoint."""
    params = {"format": "json", "per_page": 1000}
    if extra_params:
        params.update(extra_params)
    all_records, page, total_pages = [], 1, None

    while total_pages is None or page <= total_pages:
        params["page"] = page
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        meta, records = resp.json()[0], resp.json()[1]
        if total_pages is None:
            total_pages = int(meta["pages"])
        if records:
            all_records.extend(records)
        print(f"  page {page}/{total_pages} — {len(records or [])} records")
        page += 1
    return all_records

# ── Helper: write raw JSON to bronze ───────────────────────────────────────
def write_raw_bronze(records: list, table_name: str):
    """Write raw JSON records to a bronze table for audit/replay."""
    if not records:
        print(f"  No records for {table_name}, skipping."); return
    
    schema = StructType([
        StructField("raw_json",    StringType(), False),
        StructField("ingested_at", StringType(), False),
    ])
    rows = [(json.dumps(r), RUN_TS) for r in records]
    df   = spark.createDataFrame(rows, schema=schema)
    full = f"{CATALOG}.{SCHEMA}.{table_name}"
    
    (df.write.format("delta").mode("append")
       .option("mergeSchema", "true").saveAsTable(full))
    
    print(f"  ✓ Written {df.count()} raw records → {full}")
    return df

# ═══════════════════════════════════════════════════════════════════════════
# STEP 1: Extract and Parse Country Dimension with Hierarchy
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*80)
print("STEP 1: Extracting Country Dimension with Hierarchy")
print("="*80)

country_records = fetch_all_pages(f"{BASE}/country", {"per_page": 300})
write_raw_bronze(country_records, "raw_countries")

# Parse country JSON into structured dimension table
print("\nParsing country hierarchy...")

country_schema = StructType([
    StructField("country_id",      StringType(), True),
    StructField("country_code",    StringType(), True),  # ISO2
    StructField("country_code_iso3", StringType(), True),  # ISO3
    StructField("country_name",    StringType(), True),
    StructField("region_id",       StringType(), True),
    StructField("region_name",     StringType(), True),
    StructField("region_code",     StringType(), True),
    StructField("admin_region_id", StringType(), True),
    StructField("admin_region_name", StringType(), True),
    StructField("admin_region_code", StringType(), True),
    StructField("income_level_id",   StringType(), True),
    StructField("income_level_name", StringType(), True),
    StructField("income_level_code", StringType(), True),
    StructField("lending_type_id",   StringType(), True),
    StructField("lending_type_name", StringType(), True),
    StructField("lending_type_code", StringType(), True),
    StructField("capital_city",    StringType(), True),
    StructField("longitude",       StringType(), True),
    StructField("latitude",        StringType(), True),
    StructField("extraction_date", DateType(),   False),
])

df_countries_raw = spark.createDataFrame(
    [(json.dumps(r),) for r in country_records], 
    ["json_str"]
)

df_countries = df_countries_raw.select(
    get_json_object(col("json_str"), "$.id").alias("country_id"),  # Primary country ID (ISO3)
    get_json_object(col("json_str"), "$.iso2Code").alias("country_code"),  # ISO2 code
    get_json_object(col("json_str"), "$.id").alias("country_code_iso3"),  # ISO3 code
    get_json_object(col("json_str"), "$.name").alias("country_name"),
    get_json_object(col("json_str"), "$.region.id").alias("region_id"),
    get_json_object(col("json_str"), "$.region.value").alias("region_name"),
    get_json_object(col("json_str"), "$.region.iso2code").alias("region_code"),
    get_json_object(col("json_str"), "$.adminregion.id").alias("admin_region_id"),
    get_json_object(col("json_str"), "$.adminregion.value").alias("admin_region_name"),
    get_json_object(col("json_str"), "$.adminregion.iso2code").alias("admin_region_code"),
    get_json_object(col("json_str"), "$.incomeLevel.id").alias("income_level_id"),
    get_json_object(col("json_str"), "$.incomeLevel.value").alias("income_level_name"),
    get_json_object(col("json_str"), "$.incomeLevel.iso2code").alias("income_level_code"),
    get_json_object(col("json_str"), "$.lendingType.id").alias("lending_type_id"),
    get_json_object(col("json_str"), "$.lendingType.value").alias("lending_type_name"),
    get_json_object(col("json_str"), "$.lendingType.iso2code").alias("lending_type_code"),
    get_json_object(col("json_str"), "$.capitalCity").alias("capital_city"),
    get_json_object(col("json_str"), "$.longitude").alias("longitude"),
    get_json_object(col("json_str"), "$.latitude").alias("latitude"),
    lit(RUN_DATE).alias("extraction_date")
).filter(
    # Filter out aggregates and regions (keep only countries)
    (col("region_name") != "Aggregates") & 
    col("country_code_iso3").isNotNull() & 
    (col("country_code_iso3") != "")
)

countries_table = f"{CATALOG}.{SCHEMA}.countries"
(df_countries.write.format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .partitionBy("extraction_date")
    .saveAsTable(countries_table))

print(f"  ✓ Written {df_countries.count()} countries → {countries_table}")

# ═══════════════════════════════════════════════════════════════════════════
# STEP 2: Extract Indicators and Create Unified Fact Table
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*80)
print("STEP 2: Extracting Indicators")
print("="*80)

# Define indicator codes with metadata
indicators = {
    "GDP": {
        "code": "NY.GDP.MKTP.CD",
        "name": "GDP (current US$)",
        "raw_table": "raw_gdp"
    },
    "Population": {
        "code": "SP.POP.TOTL",
        "name": "Population, total",
        "raw_table": "raw_population"
    },
    "GDP per Capita": {
        "code": "NY.GDP.PCAP.CD",
        "name": "GDP per capita (current US$)",
        "raw_table": "raw_gdp_per_capita"
    },
    "Life Expectancy": {
        "code": "SP.DYN.LE00.IN",
        "name": "Life expectancy at birth, total (years)",
        "raw_table": "raw_life_expectancy"
    },
    "Education Expenditure": {
        "code": "SE.XPD.TOTL.GD.ZS",
        "name": "Government expenditure on education, total (% of GDP)",
        "raw_table": "raw_education_expend"
    },
    "Inflation": {
        "code": "FP.CPI.TOTL.ZG",
        "name": "Inflation, consumer prices (annual %)",
        "raw_table": "raw_inflation"
    },
    "Unemployment": {
        "code": "SL.UEM.TOTL.ZS",
        "name": "Unemployment, total (% of total labor force)",
        "raw_table": "raw_unemployment"
    }
}

all_indicator_dfs = []

for indicator_name, metadata in indicators.items():
    code = metadata["code"]
    raw_table = metadata["raw_table"]
    
    print(f"\nFetching {indicator_name} ({code}) for {DATE_FROM}:{DATE_TO}...")
    records = fetch_all_pages(
        f"{BASE}/country/all/indicator/{code}",
        {"date": f"{DATE_FROM}:{DATE_TO}"}
    )
    
    # Write raw JSON
    write_raw_bronze(records, raw_table)
    
    # Parse into structured format
    if records:
        df_raw = spark.createDataFrame(
            [(json.dumps(r),) for r in records],
            ["json_str"]
        )
        
        df_parsed = df_raw.select(
            get_json_object(col("json_str"), "$.indicator.id").alias("indicator_id"),
            get_json_object(col("json_str"), "$.indicator.value").alias("indicator_name"),
            get_json_object(col("json_str"), "$.country.id").alias("country_id"),
            get_json_object(col("json_str"), "$.country.value").alias("country_name"),
            get_json_object(col("json_str"), "$.countryiso3code").alias("country_code"),
            get_json_object(col("json_str"), "$.date").alias("year"),
            get_json_object(col("json_str"), "$.value").cast(DoubleType()).alias("value"),
            get_json_object(col("json_str"), "$.unit").alias("unit"),
            get_json_object(col("json_str"), "$.obs_status").alias("obs_status"),
            get_json_object(col("json_str"), "$.decimal").cast(IntegerType()).alias("decimal"),
            lit(RUN_TS).alias("extraction_timestamp"),
            lit("world_bank_api").alias("source"),
            lit(RUN_DATE).alias("extraction_date")
        )
        
        all_indicator_dfs.append(df_parsed)
        print(f"  ✓ Parsed {df_parsed.count()} records for {indicator_name}")

# ═══════════════════════════════════════════════════════════════════════════
# STEP 3: Combine All Indicators into Unified Table with Country Hierarchy
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*80)
print("STEP 3: Creating Unified Indicators Table")
print("="*80)

if all_indicator_dfs:
    # Union all indicator dataframes
    from functools import reduce
    df_all_indicators = reduce(lambda a, b: a.union(b), all_indicator_dfs)
    
    # Join with country hierarchy to enrich indicators
    # Use inner join to automatically filter out regional aggregates
    # (aggregates like "Africa Eastern and Southern" won't match any country in the dimension)
    df_indicators_enriched = df_all_indicators.join(
        df_countries.select(
            col("country_code_iso3").alias("country_code"),
            col("region_id"),
            col("region_name"),
            col("region_code"),
            col("income_level_id"),
            col("income_level_name"),
            col("income_level_code"),
            col("lending_type_id"),
            col("lending_type_name"),
            col("capital_city")
        ),
        on="country_code",
        how="inner"  # Changed from "left" to "inner" to exclude aggregates
    )
    
    indicators_table = f"{CATALOG}.{SCHEMA}.indicators"
    
    (df_indicators_enriched.write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .partitionBy("extraction_date")
        .saveAsTable(indicators_table))
    
    total_records = df_indicators_enriched.count()
    print(f"  ✓ Written {total_records} indicator records → {indicators_table}")
    print(f"  ✓ Enriched with country hierarchy (region, income level, lending type)")
else:
    print("  ! No indicator data to write")

# ═══════════════════════════════════════════════════════════════════════════
# STEP 4: Summary and Statistics
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*80)
print("EXTRACTION COMPLETE")
print("="*80)
print(f"Run Timestamp: {RUN_TS}")
print(f"Run Date: {RUN_DATE}")
print(f"Date Range: {DATE_FROM} - {DATE_TO}")
print(f"\nTables created:")
print(f"  • {CATALOG}.{SCHEMA}.countries (dimension with hierarchy)")
print(f"  • {CATALOG}.{SCHEMA}.indicators (fact table enriched with hierarchy)")
print(f"  • {CATALOG}.{SCHEMA}.raw_* (raw JSON audit tables)")
print("="*80)

# COMMAND ----------

# DBTITLE 1,Verify Enriched Indicators with Hierarchy
# MAGIC %sql
# MAGIC -- Sample enriched indicators showing country hierarchy integration
# MAGIC -- The indicators table now includes region, income level, and lending type
# MAGIC -- This enables analysis by geographic and economic dimensions
# MAGIC
# MAGIC SELECT 
# MAGIC     country_code,
# MAGIC     country_name,
# MAGIC     region_name,
# MAGIC     income_level_name,
# MAGIC     indicator_name,
# MAGIC     year,
# MAGIC     value
# MAGIC FROM world_bank.bronze.indicators
# MAGIC WHERE 
# MAGIC --    extraction_date = (SELECT MAX(extraction_date) FROM world_bank.bronze.indicators)
# MAGIC --    AND indicator_id = 'NY.GDP.MKTP.CD'  -- GDP
# MAGIC --    AND year = '2023'
# MAGIC --    AND value IS NOT NULL
# MAGIC --    AND region_name IS NOT NULL  -- Filter out aggregates (only show countries with hierarchy)
# MAGIC ORDER BY country_code
# MAGIC LIMIT 300

# COMMAND ----------

# DBTITLE 1,Verify Country Hierarchy Structure
# MAGIC %sql
# MAGIC -- Verify country hierarchy structure
# MAGIC -- Shows the hierarchical dimensions available for each country
# MAGIC
# MAGIC SELECT 
# MAGIC     country_code_iso3,
# MAGIC     country_name,
# MAGIC     region_name,
# MAGIC     income_level_name,
# MAGIC     lending_type_name,
# MAGIC     capital_city
# MAGIC FROM world_bank.bronze.countries
# MAGIC WHERE extraction_date = (SELECT MAX(extraction_date) FROM world_bank.bronze.countries)
# MAGIC ORDER BY country_name, region_name, income_level_name
# MAGIC LIMIT 300