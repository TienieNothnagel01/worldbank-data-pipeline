#!/bin/bash
set -e

# World Bank Lakehouse Pipeline - Container Entrypoint
# This script handles pipeline execution based on the provided mode

echo "========================================"
echo "World Bank Lakehouse Pipeline"
echo "========================================"
echo "Starting at: $(date)"
echo "Pipeline Mode: ${PIPELINE_MODE:-full}"
echo "Log Level: ${LOG_LEVEL:-INFO}"
echo "========================================"

# Function to check if required environment variables are set
check_environment() {
    local required_vars=("BRONZE_PATH" "SILVER_PATH" "GOLD_PATH" "WB_API_BASE_URL")
    local missing_vars=()
    
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            missing_vars+=("$var")
        fi
    done
    
    if [ ${#missing_vars[@]} -gt 0 ]; then
        echo "ERROR: Missing required environment variables:"
        printf ' - %s\n' "${missing_vars[@]}"
        exit 1
    fi
}

# Function to create necessary directories
setup_directories() {
    echo "Setting up data directories..."
    mkdir -p "${BRONZE_PATH}" "${SILVER_PATH}" "${GOLD_PATH}" "${LOGS_PATH}"
    echo "Directories ready."
}

# Function to run the pipeline
run_pipeline() {
    local mode="${1:-full}"
    
    echo "Executing pipeline in '${mode}' mode..."
    echo "----------------------------------------"
    
    cd /app/scripts
    
    case "${mode}" in
        "bronze")
            echo "Running Bronze layer extraction..."
            python3 extract_bronze.py
            ;;
        "silver")
            echo "Running Silver layer transformation..."
            python3 transform_silver.py
            ;;
        "gold")
            echo "Running Gold layer denormalization..."
            python3 build_gold.py
            ;;
        "bronze-silver")
            echo "Running Bronze → Silver layers..."
            python3 extract_bronze.py && python3 transform_silver.py
            ;;
        "silver-gold")
            echo "Running Silver → Gold layers..."
            python3 transform_silver.py && python3 build_gold.py
            ;;
        "full")
            echo "Running full pipeline: Bronze → Silver → Gold..."
            python3 run_pipeline.py
            ;;
        *)
            echo "ERROR: Invalid pipeline mode: ${mode}"
            echo "Valid modes: full, bronze, silver, gold, bronze-silver, silver-gold"
            exit 1
            ;;
    esac
    
    local exit_code=$?
    
    if [ ${exit_code} -eq 0 ]; then
        echo "========================================"
        echo "Pipeline completed successfully!"
        echo "Finished at: $(date)"
        echo "========================================"
    else
        echo "========================================"
        echo "Pipeline failed with exit code: ${exit_code}"
        echo "Failed at: $(date)"
        echo "========================================"
        exit ${exit_code}
    fi
}

# Main execution
main() {
    # Check environment
    check_environment
    
    # Setup directories
    setup_directories
    
    # Determine mode from argument or environment variable
    local mode="${1:-${PIPELINE_MODE:-full}}"
    
    # Run the pipeline
    run_pipeline "${mode}"
}

# Execute main function with all arguments
main "$@"