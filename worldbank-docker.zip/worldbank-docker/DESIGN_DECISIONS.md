# Design Decisions

This document explains the key architectural choices, tool selections, and design patterns used in the World Bank Data Pipeline.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Schema Design](#schema-design)
3. [Tool Choices](#tool-choices)
4. [Separation of Concerns](#separation-of-concerns)
5. [Data Quality & Validation](#data-quality--validation)
6. [Known Limitations](#known-limitations)
7. [Future Improvements](#future-improvements)

---

## Architecture Overview

### Medallion Architecture (Bronze → Silver → Gold)

We implemented the **Medallion Architecture** pattern for several reasons:

#### Why Medallion?

1. **Clear Separation of Concerns**: Each layer has a distinct purpose and transformation logic
2. **Data Lineage**: Easy to trace data from raw source through to reporting layer
3. **Incremental Processing**: Bronze can append, Silver can merge, Gold can overwrite independently
4. **Error Recovery**: Bronze preserves raw data, allowing replay without re-fetching from API
5. **Performance Optimization**: Each layer optimized for its use case (audit vs. analytics)

#### Layer Responsibilities

**Bronze (Raw Landing)**
- **Purpose**: Preserve raw API responses exactly as received
- **Format**: JSON strings stored as Parquet
- **Write Mode**: Append-only for audit trail
- **Use Case**: Data replay, debugging, compliance

**Silver (Star Schema)**
- **Purpose**: Clean, normalized, business-ready data
- **Format**: Dimensional model (star schema)
- **Write Mode**: MERGE (upsert) for idempotency
- **Use Case**: Analytics, ad-hoc queries, data science

**Gold (Reporting Layer)**
- **Purpose**: Denormalized, pre-aggregated for BI tools
- **Format**: Wide tables and summary tables
- **Write Mode**: Overwrite for deterministic output
- **Use Case**: Dashboards, reports, KPIs

---

## Schema Design

### Silver Layer: Star Schema

We chose **star schema** over other dimensional modeling approaches:

#### Why Star Schema?

1. **Simplicity**: Easy to understand and query (fewer JOINs than snowflake)
2. **Query Performance**: Fewer JOINs = faster queries
3. **BI Tool Compatibility**: Most BI tools optimize for star schema
4. **Flexibility**: Easy to add new dimensions or facts

#### Dimension Tables

**dim_country** (Type 1 SCD)
- **Surrogate Key**: `country_key` (auto-increment)
- **Natural Key**: `country_code` (ISO3)
- **Why Type 1?**: Country attributes rarely change; when they do, we want current view
- **Additional Fields**: Region hierarchy (region_id, region_name), income level, lending type
- **Design Choice**: Embedded hierarchy (denormalized) for query simplicity vs. snowflake

**dim_indicator** (Type 1 SCD)
- **Surrogate Key**: `indicator_key` (auto-increment)
- **Natural Key**: `indicator_id` (World Bank code)
- **Why Type 1?**: Indicator definitions are stable; metadata changes are rare
- **Unit Field**: Preserved for context (%, currency, etc.)

**dim_date**
- **Surrogate Key**: `date_key` (YYYYMMDD format)
- **Why Date Dimension?**: Enables fiscal year calculations, decade analysis, time intelligence
- **Grain**: Year (not full date) since World Bank data is annual
- **Trade-off**: Simpler than full date dimension but sufficient for annual indicators

#### Fact Table

**fact_indicator_values**
- **Grain**: One row per country-indicator-year combination
- **Keys**: country_key, indicator_key, date_key (foreign keys)
- **Measures**: `value` (the actual indicator value)
- **Audit Fields**: extraction_timestamp, source
- **Why This Grain?**: Natural grain of World Bank data; allows flexible aggregation

#### Referential Integrity

- **Enforced via JOINs**: PySpark enforces through inner joins during transformation
- **Orphan Handling**: Records without matching country are logged separately (not silently dropped)
- **Trade-off**: No database-level foreign keys (Delta Lake limitation) but validated in code

### Gold Layer: Denormalization

#### Wide Table (gold_country_indicators)

**Design**: Pivot all indicators into columns

```
Country | Year | NY.GDP.MKTP.CD | SP.POP.TOTL | ...
--------|------|----------------|-------------|-----
USA     | 2023 | 27360935000000 | 339996564   | ...
```

**Why Pivot?**
1. **Ease of Use**: Business users can filter/sort without understanding JOINs
2. **Excel-like**: Familiar layout for non-technical users
3. **BI Performance**: Single table query vs. multiple JOINs

**Trade-off**: Schema changes when new indicators added (acceptable for stable indicator set)

#### Trend Table (gold_indicator_trends)

**Design**: Time-series with global statistics

**Why Pre-aggregate?**
1. **Performance**: Expensive aggregations computed once
2. **Consistency**: Everyone sees same calculations
3. **Trending**: YoY calculations enable trend analysis

**Statistics Included**:
- Central Tendency: mean, median
- Spread: stddev, min, max, percentiles (25th, 75th)
- Change: YoY absolute and percentage change

#### Summary Table (gold_country_summary)

**Purpose**: Data completeness metrics per country

**Why Needed?**
1. **Data Quality**: Identifies countries with sparse data
2. **Reporting Confidence**: Users know data coverage before analysis
3. **Monitoring**: Tracks data availability over time

---

## Tool Choices

### PySpark vs. Pandas

**Chosen**: PySpark

**Rationale**:
1. **Scalability**: Handles millions of records without memory issues
2. **Distributed Processing**: Parallelizes API calls and transformations
3. **Delta Lake Integration**: Native support for ACID transactions
4. **Future-Proof**: Can scale to cluster if data volume grows

**Trade-off**: More complex than Pandas, but necessary for production scale

### Delta Lake vs. Parquet

**Chosen**: Delta Lake (Parquet under the hood)

**Rationale**:
1. **ACID Transactions**: Ensures data consistency during concurrent writes
2. **Time Travel**: Can query historical versions
3. **Schema Evolution**: Handles schema changes gracefully
4. **MERGE Operations**: Native upsert support for Silver layer

**When Plain Parquet**: Bronze layer uses Parquet (append-only, no MERGE needed)

### Docker vs. Native Installation

**Chosen**: Docker

**Rationale**:
1. **Reproducibility**: Exact same environment everywhere
2. **Isolation**: No dependency conflicts
3. **Portability**: Works on Linux, Mac, Windows
4. **Onboarding**: New developers up and running in minutes

**Trade-off**: Slightly more overhead than native, but consistency wins

### REST API vs. Bulk Download

**Chosen**: REST API (with pagination and retry logic)

**Rationale**:
1. **Incremental Updates**: Can fetch only new data
2. **Filtering**: API supports country/year filtering
3. **Always Fresh**: No stale download files
4. **Retry Logic**: Handles transient failures gracefully

**Trade-off**: Slower than bulk download, but more flexible

---

## Separation of Concerns

### Layer Isolation

Each layer has **dedicated Python script**:

```
extract_bronze.py   → Bronze layer only
transform_silver.py → Silver layer only
build_gold.py       → Gold layer only
run_pipeline.py     → Orchestration only
```

**Benefits**:
1. **Testability**: Can test each layer independently
2. **Maintainability**: Changes isolated to one file
3. **Partial Execution**: Can run only Silver if Bronze unchanged
4. **Parallel Development**: Multiple developers can work on different layers

### Configuration Management

**Approach**: Environment variables + `.env` file

**Why Environment Variables?**
1. **12-Factor App**: Industry standard for configuration
2. **Secrets Management**: Can inject from secret store in production
3. **Environment-Specific**: Dev/staging/prod configs without code changes
4. **Docker-Friendly**: Easy to pass to containers

**Alternative Considered**: YAML config files (rejected: more complex, less Docker-friendly)

### Error Handling

**Strategy**: Fail fast + comprehensive logging

1. **API Errors**: Retry with exponential backoff, then fail
2. **Data Errors**: Log and continue (don't fail entire pipeline for one bad record)
3. **Schema Errors**: Fail immediately (schema issues require investigation)

**Logging Levels**:
- **DEBUG**: API requests, transformation details
- **INFO**: Pipeline progress, record counts
- **WARNING**: Retries, missing data
- **ERROR**: Failed API calls, unrecoverable errors

---

## Data Quality & Validation

### Validation Strategy

**Three-Tier Approach**:

1. **Schema Validation** (Compile-time)
   - PySpark enforces data types
   - Required fields checked during transformation

2. **Business Rule Validation** (Runtime)
   - Year format: 4-digit, 2000-2030 range
   - Country codes: 3-character ISO3 format
   - No duplicate facts at grain level

3. **Completeness Checks** (Post-load)
   - Record counts match expectations
   - Null values within acceptable thresholds
   - Referential integrity verified

### Idempotency

**Goal**: Re-running pipeline produces same result

**Implementation**:

1. **Bronze Layer**
   - Append with `extraction_timestamp`
   - Deduplication happens in Silver (not Bronze)
   - Reasoning: Preserve all API responses for audit

2. **Silver Layer**
   - MERGE on composite key (country_code, indicator_id, year)
   - `updated_timestamp` tracks latest change
   - Reasoning: Idempotent; re-running updates existing records

3. **Gold Layer**
   - Overwrite mode (full refresh)
   - Deterministic output from Silver data
   - Reasoning: Always consistent with Silver state

---

## Known Limitations

### 1. No Incremental Bronze Loading

**Current**: Bronze appends all data every run

**Impact**: Wastes API calls and storage for unchanged data

**Workaround**: Use date range filters (`WB_START_YEAR`, `WB_END_YEAR`)

**Future Fix**: Implement watermark (track last extraction timestamp per indicator)

### 2. Limited Error Recovery

**Current**: Failed API calls abort that indicator extraction

**Impact**: One bad indicator can block others

**Workaround**: Run failed indicators separately

**Future Fix**: Implement per-indicator checkpointing

### 3. No Schema Evolution in Gold

**Current**: Adding new indicator requires code change (pivot logic)

**Impact**: Not fully dynamic for new indicators

**Workaround**: Add new indicator to pivot list manually

**Future Fix**: Dynamic pivot based on Silver dim_indicator table

### 4. Single-Node Spark

**Current**: Docker runs Spark in local mode (single machine)

**Impact**: Limited to millions (not billions) of records

**Workaround**: Sufficient for World Bank data volume

**Future Fix**: Deploy to Databricks or EMR for cluster mode

### 5. No Data Governance

**Current**: No data lineage tracking, data catalog, or column-level metadata

**Impact**: Hard to track data provenance at scale

**Workaround**: Manual documentation

**Future Fix**: Integrate with Unity Catalog or Alation

### 6. API Rate Limiting

**Current**: No built-in rate limiting beyond retries

**Impact**: Could hit World Bank API rate limits at scale

**Workaround**: Reduce parallel requests, add delays

**Future Fix**: Implement token bucket rate limiter

---

## Future Improvements

### Short-Term (1-2 weeks)

1. **Add Data Quality Metrics**
   - Automated alerts for data freshness
   - Threshold-based quality checks
   - Great Expectations integration

2. **Improve Test Coverage**
   - Integration tests with test fixtures
   - Contract tests for API schema
   - Performance benchmarks

3. **Enhanced Logging**
   - Structured logging (JSON format)
   - Log aggregation (send to ELK stack)
   - Pipeline execution metrics

### Medium-Term (1-2 months)

1. **Orchestration Upgrade**
   - Replace `run_pipeline.py` with Prefect or Airflow
   - DAG-based execution with dependencies
   - SLA monitoring and alerting

2. **Incremental Loading**
   - Watermark-based extraction
   - Change Data Capture (CDC) from Silver to Gold
   - Reduce data transfer and processing time

3. **Data Catalog**
   - Integrate with Unity Catalog or Alation
   - Auto-generate data dictionary
   - Track column-level lineage

### Long-Term (3-6 months)

1. **Multi-Cloud Deployment**
   - Terraform for infrastructure-as-code
   - Deploy to AWS, Azure, or GCP
   - Kubernetes for container orchestration

2. **Streaming Architecture**
   - Real-time data ingestion (if World Bank adds streaming API)
   - Kafka + Spark Structured Streaming
   - Near-real-time Gold layer updates

3. **Machine Learning Integration**
   - Feature store for ML models
   - Automated forecasting (GDP, population trends)
   - Anomaly detection for data quality

4. **Self-Service Analytics**
   - SQL interface (Trino/Presto)
   - Notebook environment (Jupyter)
   - BI tool integration (Tableau, Power BI, Looker)

---

## Trade-offs Summary

| Decision | Chosen | Alternative | Trade-off |
|----------|--------|-------------|----------|
| Architecture | Medallion | Single-layer lakehouse | More complexity, better separation |
| Dimensional Model | Star schema | Snowflake schema | Fewer JOINs, some denormalization |
| Processing | PySpark | Pandas | More scalable, steeper learning curve |
| Storage | Delta Lake | Plain Parquet | ACID guarantees, slight overhead |
| Containerization | Docker | Native install | Reproducibility, slight performance cost |
| API Strategy | REST + pagination | Bulk download | Flexibility, slower |
| Gold Layer | Wide table | Normalized | Ease of use, schema rigidity |
| Error Handling | Fail fast | Continue on error | Data quality, less fault tolerance |

---

## Conclusion

The design prioritizes:

1. **Maintainability**: Clear separation, modular code
2. **Scalability**: Distributed processing, incremental updates
3. **Reliability**: Idempotency, ACID transactions, comprehensive testing
4. **Usability**: Denormalized Gold layer, self-documenting code

These choices balance **production readiness** with **development speed**, making the pipeline suitable for both initial deployment and long-term evolution.
