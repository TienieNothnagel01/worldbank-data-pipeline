# World Bank Lakehouse Pipeline - Docker Image
# Multi-stage build for optimized image size

FROM python:3.10-slim as builder

# Install system dependencies required for PySpark and compilation
RUN apt-get update && apt-get install -y --no-install-recommends \
    openjdk-17-jre-headless \
    procps \
    wget \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Set Java environment variables
ENV JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
ENV PATH="${JAVA_HOME}/bin:${PATH}"

# Create application directory
WORKDIR /app

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir -r requirements.txt

# Final stage
FROM python:3.10-slim

# Install runtime dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    openjdk-17-jre-headless \
    procps \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Set Java environment variables
ENV JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
ENV PATH="${JAVA_HOME}/bin:${PATH}"

# Copy Python packages from builder
COPY --from=builder /usr/local/lib/python3.10/site-packages /usr/local/lib/python3.10/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

# Set up application directory structure
WORKDIR /app
RUN mkdir -p /app/scripts /app/data/bronze /app/data/silver /app/data/gold /app/logs

# Copy application scripts
COPY scripts/ /app/scripts/
COPY entrypoint.sh /app/

# Make scripts executable
RUN chmod +x /app/entrypoint.sh && \
    chmod +x /app/scripts/*.py

# Set PySpark configuration for local mode
ENV SPARK_HOME=/usr/local/lib/python3.10/site-packages/pyspark
ENV PYSPARK_PYTHON=python3
ENV PYSPARK_DRIVER_PYTHON=python3

# Configure Spark to run in local mode with optimized settings
ENV SPARK_LOCAL_DIRS=/tmp/spark
ENV SPARK_WORKER_DIR=/tmp/spark-worker

# Create non-root user for security
RUN useradd -m -u 1000 sparkuser && \
    chown -R sparkuser:sparkuser /app /tmp

USER sparkuser

# Expose port for Spark UI (optional, for monitoring)
EXPOSE 4040

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD python3 -c "import pyspark; print('healthy')" || exit 1

# Set entrypoint
ENTRYPOINT ["/app/entrypoint.sh"]

# Default command runs the full pipeline
CMD ["full"]